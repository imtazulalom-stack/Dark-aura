package com.aurax.panel.ui.activation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurax.panel.data.license.ActivationError
import com.aurax.panel.data.license.ActivationResult
import com.aurax.panel.data.license.LicenseKey
import com.aurax.panel.data.license.LicenseManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ActivationUiState(
    val keyBody: String = "",
    val isLoading: Boolean = false,
    val error: ActivationError? = null,
    val activated: Boolean = false
)

class ActivationViewModel(app: Application) : AndroidViewModel(app) {

    private val manager = LicenseManager.get(app)

    private val _state = MutableStateFlow(ActivationUiState())
    val state: StateFlow<ActivationUiState> = _state.asStateFlow()

    fun onKeyChanged(raw: String) {
        if (_state.value.isLoading) return
        _state.update { it.copy(keyBody = LicenseKey.clean(raw), error = null) }
    }

    fun onActivateClicked() {
        val current = _state.value
        if (current.isLoading) return

        val problem = when {
            !LicenseKey.isComplete(current.keyBody) -> ActivationError.InvalidFormat
            LicenseKey.hasInvalidChars(current.keyBody) -> ActivationError.InvalidCharacters
            else -> null
        }
        if (problem != null) {
            _state.update { it.copy(error = problem) }
            return
        }

        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val result: ActivationResult = try {
                manager.activate(LicenseKey.full(current.keyBody))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ActivationResult.Failure(ActivationError.Unknown)
            }
            _state.update {
                when (result) {
                    is ActivationResult.Success -> it.copy(isLoading = false, activated = true)
                    is ActivationResult.Failure -> it.copy(isLoading = false, error = result.error)
                }
            }
        }
    }
}
