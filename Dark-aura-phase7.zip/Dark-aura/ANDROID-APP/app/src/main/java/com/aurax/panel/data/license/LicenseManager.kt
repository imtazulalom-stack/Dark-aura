package com.aurax.panel.data.license

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Owns the license on this phone.
 *
 * - The key and the last server-verified expiry are stored locally.
 * - Remaining time = expiry - (server time at last check + time elapsed since then), where elapsed time
 *   comes from SystemClock.elapsedRealtime(). It is monotonic, so changing the phone's date/clock does
 *   NOT change it, and closing the app does not reset it.
 * - Offline use is allowed only for a short grace period (6 h) and only until the phone reboots.
 *   Otherwise the app must check with the server again.
 * - Re-checks with the server every 5 minutes while the app is running (catches revoked keys).
 */
class LicenseManager private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("aurax_license", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val deviceId: String = run {
        val androidId = Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
        if (!androidId.isNullOrBlank() && androidId.length >= 8) androidId
        else prefs.getString(KEY_FALLBACK_ID, null) ?: UUID.randomUUID().toString().replace("-", "").also {
            prefs.edit().putString(KEY_FALLBACK_ID, it).apply()
        }
    }
    private val repo = FirebaseLicenseRepository(deviceId)

    private val _display = MutableStateFlow<LicenseDisplay>(LicenseDisplay.NotVerified)
    val display: StateFlow<LicenseDisplay> = _display.asStateFlow()

    private var monitor: Job? = null

    /** Called once at app start. Returns true if the user may enter the app. */
    suspend fun checkOnStartup(): Boolean {
        val key = prefs.getString(KEY_LICENSE, null) ?: return false
        return when (val r = repo.verify(key)) {
            is VerifyResult.Ok -> {
                saveCache(key, r.expiresAtMs, r.serverNowMs)
                startMonitor()
                true
            }
            VerifyResult.Expired, VerifyResult.Revoked, VerifyResult.Invalid -> {
                clear()
                false
            }
            VerifyResult.Network, VerifyResult.ServerNotReady -> {
                if (offlineStillAllowed()) {
                    startMonitor()
                    true
                } else {
                    false
                }
            }
        }
    }

    suspend fun activate(fullKey: String): ActivationResult {
        val result = repo.activate(fullKey)
        if (result is ActivationResult.Success) {
            saveCache(fullKey, result.expiresAtMillis, result.serverNowMillis)
            startMonitor()
        }
        return result
    }

    // ---------------- internals ----------------

    private fun bootCount(): Int = try {
        Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT)
    } catch (e: Exception) {
        -1
    }

    private fun saveCache(key: String, expiresAtMs: Long, serverNowMs: Long) {
        prefs.edit()
            .putString(KEY_LICENSE, key)
            .putLong(KEY_EXPIRES, expiresAtMs)
            .putLong(KEY_SERVER_AT_SYNC, serverNowMs)
            .putLong(KEY_ELAPSED_AT_SYNC, SystemClock.elapsedRealtime())
            .putInt(KEY_BOOT, bootCount())
            .apply()
    }

    private fun clear() {
        prefs.edit()
            .remove(KEY_LICENSE).remove(KEY_EXPIRES).remove(KEY_SERVER_AT_SYNC)
            .remove(KEY_ELAPSED_AT_SYNC).remove(KEY_BOOT)
            .apply()
    }

    private fun offlineAgeMs(): Long = SystemClock.elapsedRealtime() - prefs.getLong(KEY_ELAPSED_AT_SYNC, 0L)

    /** Remaining milliseconds, or null when the cache cannot be trusted (missing, or phone rebooted). */
    private fun remainingMs(): Long? {
        if (!prefs.contains(KEY_EXPIRES)) return null
        val since = offlineAgeMs()
        val boot = prefs.getInt(KEY_BOOT, -1)
        if (since < 0 || boot == -1 || boot != bootCount()) return null
        return prefs.getLong(KEY_EXPIRES, 0L) - (prefs.getLong(KEY_SERVER_AT_SYNC, 0L) + since)
    }

    private fun offlineStillAllowed(): Boolean {
        val rem = remainingMs() ?: return false
        return rem > 0 && offlineAgeMs() <= MAX_OFFLINE_MS
    }

    private suspend fun reverify(): Boolean {
        val key = prefs.getString(KEY_LICENSE, null) ?: return false
        return when (val r = repo.verify(key)) {
            is VerifyResult.Ok -> {
                saveCache(key, r.expiresAtMs, r.serverNowMs)
                true
            }
            VerifyResult.Expired, VerifyResult.Revoked, VerifyResult.Invalid -> false
            VerifyResult.Network, VerifyResult.ServerNotReady -> offlineStillAllowed()
        }
    }

    private fun finish() {
        clear()
        _display.value = LicenseDisplay.Expired
    }

    private fun startMonitor() {
        if (monitor?.isActive == true) return
        monitor = scope.launch {
            var ticks = 0
            while (isActive) {
                var rem = remainingMs()
                if (rem == null || (ticks > 0 && ticks % VERIFY_EVERY_SECONDS == 0)) {
                    if (!reverify()) {
                        finish()
                        return@launch
                    }
                    rem = remainingMs()
                }
                if (rem == null || rem <= 0L) {
                    finish()
                    return@launch
                }
                _display.value = LicenseDisplay.Active(rem / 1000L)
                delay(1000L)
                ticks++
            }
        }
    }

    companion object {
        private const val KEY_LICENSE = "license_key"
        private const val KEY_EXPIRES = "expires_ms"
        private const val KEY_SERVER_AT_SYNC = "server_ms_at_sync"
        private const val KEY_ELAPSED_AT_SYNC = "elapsed_at_sync"
        private const val KEY_BOOT = "boot_count"
        private const val KEY_FALLBACK_ID = "fallback_device_id"
        private const val MAX_OFFLINE_MS = 6L * 60L * 60L * 1000L
        private const val VERIFY_EVERY_SECONDS = 300

        @Volatile
        private var instance: LicenseManager? = null

        fun get(context: Context): LicenseManager =
            instance ?: synchronized(this) {
                instance ?: LicenseManager(context).also { instance = it }
            }
    }
}
