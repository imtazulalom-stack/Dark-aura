package com.aurax.panel.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.aurax.panel.data.game.GamePreferences
import com.aurax.panel.data.game.GameVersion
import androidx.lifecycle.viewModelScope
import com.aurax.panel.data.license.LicenseDisplay
import com.aurax.panel.data.license.LicenseManager
import com.aurax.panel.data.profile.ProfilePreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val playerName: String,
    val game: GameVersion?,
    val license: LicenseDisplay
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val gamePrefs = GamePreferences(app)
    private val profilePrefs = ProfilePreferences(app)
    private val licenseManager = LicenseManager.get(app)

    private val _state = MutableStateFlow(load())
    val state: StateFlow<MainUiState> = _state.asStateFlow()

    private fun load() = MainUiState(
        playerName = profilePrefs.getName(),
        game = gamePrefs.getSelected(),
        license = licenseManager.display.value
    )

    init {
        // Live license status + countdown from the server-verified license.
        viewModelScope.launch {
            licenseManager.display.collect { d -> _state.update { it.copy(license = d) } }
        }
    }

    /** Called when the screen becomes visible again (e.g. after changing the game). */
    fun reload() {
        _state.value = load()
    }

    /** Returns true if the name was valid and saved. */
    fun saveName(raw: String): Boolean {
        val name = ProfilePreferences.sanitize(raw)
        if (name.length < ProfilePreferences.MIN_NAME) return false
        profilePrefs.setName(name)
        _state.update { it.copy(playerName = name) }
        return true
    }
}
