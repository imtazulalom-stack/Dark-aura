package com.aurax.panel.data.license

import kotlinx.coroutines.delay

enum class ActivationError {
    InvalidFormat,      // key is not 16 characters
    InvalidCharacters,  // contains I, O, 0 or 1 (never used in keys)
    NotFound,           // server: no such key
    AlreadyUsed,        // server: key was activated before
    Revoked,            // server: admin revoked the key
    Expired,            // server: license time is over
    Network,            // no internet / server unreachable
    NotConnected,       // Firebase not ready (Anonymous sign-in off or rules not published)
    Unknown
}

sealed interface ActivationResult {
    data class Success(val expiresAtMillis: Long, val serverNowMillis: Long = 0L) : ActivationResult
    data class Failure(val error: ActivationError) : ActivationResult
}

interface ActivationRepository {
    /** [fullKey] looks like AURA-XXXX-XXXX-XXXX-XXXX */
    suspend fun activate(fullKey: String): ActivationResult
}

/**
 * Phase 3 stand-in. It NEVER activates anything: it always answers "not connected".
 * Phase 7 replaces it with the real Firebase implementation.
 */
class NotConnectedActivationRepository : ActivationRepository {
    override suspend fun activate(fullKey: String): ActivationResult {
        delay(700) // only so the loading indicator is visible; removed in Phase 7
        return ActivationResult.Failure(ActivationError.NotConnected)
    }
}
