package com.aurax.panel.data.license

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

sealed interface VerifyResult {
    data class Ok(val expiresAtMs: Long, val serverNowMs: Long) : VerifyResult
    data object Expired : VerifyResult
    data object Revoked : VerifyResult
    data object Invalid : VerifyResult
    data object Network : VerifyResult
    data object ServerNotReady : VerifyResult
}

/**
 * Real license checks against Cloud Firestore (free Spark plan, no Cloud Functions).
 *
 * Trust model: start time comes from Firestore SERVER time (enforced by the security rules),
 * and "now" is read back from the server too. The phone's clock is never used for validity.
 */
class FirebaseLicenseRepository(private val deviceId: String) : ActivationRepository {

    private class ServerNotReadyException : Exception()

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    private data class Doc(
        val exists: Boolean,
        val status: String?,
        val deviceId: String?,
        val activatedAtMs: Long?,
        val durationMs: Long
    )

    private suspend fun uid(): String {
        auth.currentUser?.let { return it.uid }
        try {
            return auth.signInAnonymously().await().user?.uid ?: throw ServerNotReadyException()
        } catch (e: FirebaseAuthException) {
            throw ServerNotReadyException()
        }
    }

    private suspend fun serverNowMs(uid: String): Long {
        val ref = db.collection("clock").document(uid)
        ref.set(mapOf("t" to FieldValue.serverTimestamp())).await()
        val snap = ref.get(Source.SERVER).await()
        return snap.getTimestamp("t")?.toDate()?.time ?: throw FirebaseNetworkException("no server time")
    }

    private suspend fun read(key: String): Doc {
        val s = db.collection("licenses").document(key).get(Source.SERVER).await()
        if (!s.exists()) return Doc(false, null, null, null, 0L)
        return Doc(
            exists = true,
            status = s.getString("status"),
            deviceId = s.getString("deviceId"),
            activatedAtMs = s.getTimestamp("activatedAt")?.toDate()?.time,
            durationMs = (s.getLong("durationSec") ?: 0L) * 1000L
        )
    }

    private fun mapError(e: Exception): ActivationError = when (e) {
        is ServerNotReadyException -> ActivationError.NotConnected
        is FirebaseNetworkException -> ActivationError.Network
        is FirebaseFirestoreException -> when (e.code) {
            FirebaseFirestoreException.Code.UNAVAILABLE,
            FirebaseFirestoreException.Code.DEADLINE_EXCEEDED -> ActivationError.Network
            FirebaseFirestoreException.Code.PERMISSION_DENIED -> ActivationError.NotConnected
            else -> ActivationError.Unknown
        }
        else -> ActivationError.Unknown
    }

    // ---------------- activate ----------------

    override suspend fun activate(fullKey: String): ActivationResult {
        return try {
            withTimeoutOrNull(25_000L) { doActivate(fullKey) }
                ?: ActivationResult.Failure(ActivationError.Network)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ActivationResult.Failure(mapError(e))
        }
    }

    private suspend fun doActivate(key: String): ActivationResult {
        uid() // makes sure we are signed in (anonymously)
        val ref = db.collection("licenses").document(key)
        val d = read(key)
        if (!d.exists) return ActivationResult.Failure(ActivationError.NotFound)

        when (d.status) {
            "revoked" -> return ActivationResult.Failure(ActivationError.Revoked)
            "active" -> if (d.deviceId != deviceId) {
                return ActivationResult.Failure(ActivationError.AlreadyUsed)
            }
            "unused" -> {
                try {
                    ref.update(
                        mapOf(
                            "status" to "active",
                            "deviceId" to deviceId,
                            "activatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } catch (e: FirebaseFirestoreException) {
                    if (e.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw e
                    // Either the rules reject it, or someone activated the key a moment ago.
                    val again = read(key)
                    if (again.status == "unused") {
                        return ActivationResult.Failure(ActivationError.NotConnected)
                    }
                    if (again.status != "active" || again.deviceId != deviceId) {
                        return ActivationResult.Failure(ActivationError.AlreadyUsed)
                    }
                }
            }
            else -> return ActivationResult.Failure(ActivationError.Unknown)
        }

        return when (val v = verify(key)) {
            is VerifyResult.Ok -> ActivationResult.Success(v.expiresAtMs, v.serverNowMs)
            VerifyResult.Expired -> ActivationResult.Failure(ActivationError.Expired)
            VerifyResult.Revoked -> ActivationResult.Failure(ActivationError.Revoked)
            VerifyResult.Invalid -> ActivationResult.Failure(ActivationError.Unknown)
            VerifyResult.Network -> ActivationResult.Failure(ActivationError.Network)
            VerifyResult.ServerNotReady -> ActivationResult.Failure(ActivationError.NotConnected)
        }
    }

    // ---------------- verify ----------------

    suspend fun verify(key: String): VerifyResult {
        return try {
            withTimeoutOrNull(12_000L) { doVerify(key) } ?: VerifyResult.Network
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (mapError(e) == ActivationError.NotConnected) VerifyResult.ServerNotReady else VerifyResult.Network
        }
    }

    private suspend fun doVerify(key: String): VerifyResult {
        val uid = uid()
        val d = read(key)
        if (!d.exists) return VerifyResult.Invalid
        if (d.status == "revoked") return VerifyResult.Revoked
        if (d.status != "active" || d.deviceId != deviceId) return VerifyResult.Invalid
        val activatedAt = d.activatedAtMs ?: return VerifyResult.Network
        val expires = activatedAt + d.durationMs
        val now = serverNowMs(uid)
        return if (now >= expires) VerifyResult.Expired else VerifyResult.Ok(expires, now)
    }
}
