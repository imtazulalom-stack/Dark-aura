# Build the APK

Needs: Android Studio (recent) on a computer, or any CI that builds Gradle projects.

1. Put google-services.json in ANDROID-APP/app/ (see PHASE-7.md).
2. Open the ANDROID-APP folder in Android Studio, wait for Gradle sync.
3. Test build: Build > Build Bundle(s) / APK(s) > Build APK(s). Output: ANDROID-APP/app/build/outputs/apk/debug/
   (the debug APK shows a "skip activation" button; the release APK does not).
4. Release build: Build > Generate Signed App Bundle / APK > APK > create a new keystore (SAVE IT AND ITS
   PASSWORD; never commit it) > release. Output: app/build/outputs/apk/release/app-release.apk
5. Install on a phone: allow "install unknown apps" and open the APK.

Command line (computer): cd ANDROID-APP && ./gradlew assembleDebug   (needs the Gradle wrapper files/JDK 17)
