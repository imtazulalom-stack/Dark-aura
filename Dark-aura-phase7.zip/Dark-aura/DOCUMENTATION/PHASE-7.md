# Phase 7 - Real license activation (free Spark plan)

What is REAL now
- Activation: key -> checked in Firestore -> one-time activation (status unused -> active), start time =
  Firestore SERVER time (enforced by security rules).
- Remaining time = expiry - (server time at last check + elapsed time since). Elapsed time uses
  SystemClock.elapsedRealtime (monotonic): changing the phone date/clock changes nothing; restarting
  the app does not reset the timer.
- On every app start the app asks the server. Invalid/revoked/expired -> Activation screen.
- While the app is open it re-checks every 5 minutes. When time runs out (or the admin revokes), the app
  jumps to the Activation screen.
- Offline: allowed up to 6 hours after the last successful server check, and only until the phone reboots.
- Admin Website: expiry is shown as activatedAt + duration.

Honest limits (free design, no Cloud Functions)
- No rate limit on wrong keys (keys are 16 random characters, so guessing is not practical).
- Local cache is in normal SharedPreferences: on a rooted phone someone could edit it, but that can only
  extend OFFLINE use (max 6 h from the last server check); the next online check corrects it.
- Anyone who knows an unused key can activate it (that is what a key is). Keep keys private.

Package name: Firebase has the Android app registered as com.aurax.trainer, so the app's applicationId is
now com.aurax.trainer (code namespace stays com.aurax.panel).

YOUR ACTIONS (in this order)
1. Firebase > Authentication > Sign-in method > Add new provider > Anonymous > Enable > Save.
2. Firebase > Firestore > Rules: paste FIREBASE/firestore.rules (it CHANGED in this phase) > Publish.
3. Firebase > Project settings > Your apps > Android app (com.aurax.trainer) > download google-services.json.
   Put it in ANDROID-APP/app/google-services.json (same folder as app/build.gradle.kts). The build FAILS without it.
4. Upload the repo to GitHub, enable GitHub Pages, add imtazulalom-stack.github.io to Auth authorized domains.
5. Build the APK (see APK-BUILD.md).

TEST
1. Admin website: sign in, generate a 15 Minutes key.
2. App: enter the key -> Dashboard shows ACTIVE and a counting-down timer.
3. Close and reopen the app: timer continues (not reset).
4. Change the phone date/time: timer does not change.
5. Enter the same key on another phone: "already used".
6. Admin: Revoke the key. Within 5 minutes (or on next app start) the app returns to Activation.
7. Wait for expiry: app returns to Activation.
