# Deploy the Admin Website (free)

Option A: GitHub Pages (no CLI)
1. Upload the repo to GitHub.
2. Repo Settings > Pages > Source: Deploy from a branch > main, folder / (root) > Save.
3. Open https://<username>.github.io/Dark-aura/
4. Firebase > Authentication > Settings > Authorized domains > add <username>.github.io

Option B: Firebase Hosting (needs Firebase CLI on a computer): cd FIREBASE && firebase deploy --only hosting,firestore:rules

Admin login = the email/password user created in Firebase Authentication. Only the email written in
FIREBASE/firestore.rules (isAdmin) can create, list and revoke keys.
