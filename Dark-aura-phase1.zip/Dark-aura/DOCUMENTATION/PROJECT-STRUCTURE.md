# AURA X - Project Structure

Status: [done] = finished, [todo] = planned phase.

```
Dark-aura/
├── README.md
├── index.html                      [done]  redirects GitHub Pages to the admin site
├── ADMIN-WEBSITE/                  [done: Stage 1, upgraded in Phase 8]
│   ├── index.html, styles.css, app.js, firebase-config.js
├── FIREBASE/                       [done: Stage 1, updated in Phase 7]
│   ├── firestore.rules, firestore.indexes.json, firebase.json, .firebaserc
├── OPTIONAL-PAID/                  [done] Cloud Functions version (needs Blaze plan, unused)
├── DOCUMENTATION/
│   ├── SETUP.md, PROJECT-STRUCTURE.md, PHASE-1.md
└── ANDROID-APP/                    Kotlin + Jetpack Compose, package com.aurax.panel
    ├── settings.gradle.kts, build.gradle.kts, gradle.properties   [done: Phase 1]
    ├── gradle/libs.versions.toml, gradle/wrapper/                 [done: Phase 1]
    └── app/
        ├── build.gradle.kts, proguard-rules.pro                   [done: Phase 1]
        └── src/main/
            ├── AndroidManifest.xml                                [done: Phase 1]
            ├── res/ (icon, strings, colors, themes)               [done: Phase 1]
            └── java/com/aurax/panel/
                ├── MainActivity.kt                                [done: Phase 1]
                ├── ui/theme/ Color.kt Type.kt Theme.kt            [done: Phase 1]
                ├── ui/components/  glass cards, neon buttons      [todo: Phase 2-3]
                ├── ui/splash/      SplashScreen                   [todo: Phase 2]
                ├── ui/activation/  ActivationScreen + ViewModel   [todo: Phase 3]
                ├── ui/games/       GameSelectionScreen            [todo: Phase 4]
                ├── ui/home/        Dashboard                      [todo: Phase 5]
                ├── ui/features/    Sensitivity, Aim, Reaction,
                │                   Leaderboard, Custom UI         [todo: Phase 6]
                ├── ui/stats/       Statistics + charts            [todo: Phase 6]
                ├── ui/profile/     Profile + Settings             [todo: Phase 6]
                ├── navigation/     NavHost + bottom bar           [todo: Phase 5]
                └── data/           Firebase, license, local store [todo: Phase 7]
```

Phases: 1 setup, 2 splash, 3 activation UI, 4 game selection, 5 dashboard,
6 feature modules, 7 Firebase, 8 admin website, 9 security/testing, 10 APK.
