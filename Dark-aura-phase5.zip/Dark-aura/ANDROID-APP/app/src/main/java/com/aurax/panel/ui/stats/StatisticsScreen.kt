package com.aurax.panel.ui.stats

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.runtime.Composable
import com.aurax.panel.ui.components.PlaceholderContent

/** Placeholder: real history and charts are built in Phase 6, after the practice modules exist. */
@Composable
fun StatisticsScreen() {
    PlaceholderContent(
        icon = Icons.Filled.BarChart,
        title = "STATISTICS",
        message = "No practice sessions yet. Accuracy, reaction time and progress charts appear here once the practice modules are built in Phase 6."
    )
}
