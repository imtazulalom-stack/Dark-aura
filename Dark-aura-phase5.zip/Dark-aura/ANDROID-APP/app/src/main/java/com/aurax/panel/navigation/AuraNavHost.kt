package com.aurax.panel.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aurax.panel.BuildConfig
import com.aurax.panel.ui.activation.ActivationScreen
import com.aurax.panel.ui.features.ComingSoonScreen
import com.aurax.panel.ui.features.FeatureModule
import com.aurax.panel.ui.games.GameSelectionScreen
import com.aurax.panel.ui.main.MainScreen
import com.aurax.panel.ui.splash.SplashScreen

@Composable
fun AuraNavHost() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(600)) },
        exitTransition = { fadeOut(tween(600)) },
        popEnterTransition = { fadeIn(tween(600)) },
        popExitTransition = { fadeOut(tween(600)) }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    nav.navigate(Routes.ACTIVATION) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.ACTIVATION) {
            ActivationScreen(
                onActivated = { nav.goToGameSelectionAfterActivation() },
                // Debug builds only. In a release APK BuildConfig.DEBUG is false, so this is null.
                onDebugSkip = if (BuildConfig.DEBUG) {
                    { nav.goToGameSelectionAfterActivation() }
                } else null
            )
        }

        composable(Routes.GAME_SELECTION) {
            GameSelectionScreen(
                onContinue = {
                    // Came from the main screen ("Change game")? Just go back to it.
                    val cameFromMain = nav.popBackStack(Routes.MAIN, inclusive = false)
                    if (!cameFromMain) {
                        nav.navigate(Routes.MAIN) {
                            popUpTo(Routes.GAME_SELECTION) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Routes.MAIN) {
            MainScreen(
                onOpenModule = { nav.navigate(Routes.module(it.id)) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                onChangeGame = { nav.navigate(Routes.GAME_SELECTION) }
            )
        }

        composable(
            route = Routes.MODULE_PATTERN,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val module = FeatureModule.fromId(entry.arguments?.getString("id"))
            ComingSoonScreen(
                title = module?.title ?: "Module",
                message = (module?.description ?: "This module") + ". It is built in Phase 6.",
                onBack = { nav.popBackStack() },
                icon = module?.icon ?: Icons.Filled.Settings
            )
        }

        composable(Routes.SETTINGS) {
            ComingSoonScreen(
                title = "Settings",
                message = "Theme, notifications, sound, vibration, language, privacy policy, terms and logout. Built in Phase 6.",
                onBack = { nav.popBackStack() },
                icon = Icons.Filled.Settings
            )
        }
    }
}

private fun NavHostController.goToGameSelectionAfterActivation() {
    navigate(Routes.GAME_SELECTION) {
        popUpTo(Routes.ACTIVATION) { inclusive = true }
    }
}
