# AURA X (Dark-aura)

Free Fire practice panel: Android app (Kotlin + Jetpack Compose) + Admin website + Firebase.
Package: com.aurax.panel

Status: Phase 5 done (dashboard + bottom navigation). Server activation comes in Phase 7.
and DOCUMENTATION/PHASE-1.md to run the app.
Backend design (free Spark plan, Firestore rules): DOCUMENTATION/SETUP.md.
