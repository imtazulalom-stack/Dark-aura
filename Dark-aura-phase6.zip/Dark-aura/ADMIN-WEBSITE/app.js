import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, query, orderBy, limit, onSnapshot, doc, setDoc, updateDoc, serverTimestamp }
  from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const DURATIONS = {
  "15m": [900, "15 Minutes"], "30m": [1800, "30 Minutes"], "1h": [3600, "1 Hour"], "3h": [10800, "3 Hours"],
  "6h": [21600, "6 Hours"], "12h": [43200, "12 Hours"], "24h": [86400, "24 Hours"], "7d": [604800, "7 Days"], "30d": [2592000, "30 Days"]
};
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function newKey() {
  const b = new Uint8Array(16); crypto.getRandomValues(b);
  let o = ""; for (const x of b) o += ALPHABET[x % 32];
  return "AURA-" + o.match(/.{4}/g).join("-");
}
const toMs = (t) => (t && t.toMillis ? t.toMillis() : null);

const $ = (id) => document.getElementById(id);
let licenses = [], filter = "all", unsubs = [];

const toast = (m) => { const t = $("toast"); t.textContent = m; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 2200); };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const statusOf = (l) => (l.status === "active" && l.expiresAtMs <= Date.now() ? "expired" : l.status);
const fmt = (ms) => (ms ? new Date(ms).toLocaleString() : "—");
function remaining(l) {
  if (statusOf(l) !== "active") return "—";
  let s = Math.floor((l.expiresAtMs - Date.now()) / 1000);
  const d = Math.floor(s / 86400); s %= 86400;
  const h = Math.floor(s / 3600); s %= 3600;
  const m = Math.floor(s / 60);
  return d ? `${d}d ${h}h` : h ? `${h}h ${m}m` : `${m}m ${s % 60}s`;
}
const errMsg = (e) => (e && e.message ? e.message.replace(/^.*?:\s*/, "") : "Something went wrong. Check your connection and retry.");

$("loginForm").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const email = $("email").value.trim(), pw = $("password").value;
  $("loginError").textContent = "";
  if (!/^\S+@\S+\.\S+$/.test(email)) return ($("loginError").textContent = "Enter a valid email address.");
  if (pw.length < 6) return ($("loginError").textContent = "Password must be at least 6 characters.");
  $("loginBtn").disabled = true; $("loginBtn").textContent = "Signing in…";
  try { await signInWithEmailAndPassword(auth, email, pw); }
  catch (e) { $("loginError").textContent = "Sign-in failed. Check your email and password."; }
  finally { $("loginBtn").disabled = false; $("loginBtn").textContent = "Sign in"; }
});
$("logoutBtn").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, async (user) => {
  unsubs.forEach((u) => u()); unsubs = [];
  if (!user) { $("app").hidden = true; $("login").hidden = false; return; }
  $("login").hidden = true; $("app").hidden = false; $("adminEmail").textContent = user.email;
  unsubs.push(onSnapshot(query(collection(db, "licenses"), orderBy("createdAt", "desc"), limit(1000)),
    (s) => {
      licenses = s.docs.map((d) => { const x = d.data();
        return { ...x, createdAtMs: toMs(x.createdAt) || Date.now(), activatedAtMs: toMs(x.activatedAt), expiresAtMs: toMs(x.expiresAt) }; });
      render();
      renderHistory(licenses.filter((l) => l.activatedAtMs).sort((a, b) => b.activatedAtMs - a.activatedAtMs).slice(0, 200));
    },
    async (e) => {
      if (e.code === "permission-denied") { await signOut(auth); $("loginError").textContent = "This account is not an admin."; }
      else toast("Could not load keys: " + errMsg(e));
    }));
});

$("genBtn").addEventListener("click", async () => {
  const count = Number($("count").value);
  $("genError").textContent = "";
  if (!Number.isInteger(count) || count < 1 || count > 50) return ($("genError").textContent = "Enter a number from 1 to 50.");
  $("genBtn").disabled = true; $("genBtn").textContent = "Generating…";
  try {
    const [sec, label] = DURATIONS[$("duration").value];
    const keys = [];
    for (let i = 0; i < count; i++) {
      const key = newKey();
      await setDoc(doc(db, "licenses", key), { key, status: "unused", durationKey: $("duration").value,
        durationLabel: label, durationSec: sec, createdAt: serverTimestamp() });
      keys.push(key);
    }
    const data = { keys };
    $("newKeys").innerHTML = data.keys.map((k) =>
      `<li><span>${esc(k)}</span><button class="btn sm ghost" data-copy="${esc(k)}">Copy</button></li>`).join("");
    toast(`${data.keys.length} key(s) generated`);
  } catch (e) { $("genError").textContent = errMsg(e); }
  finally { $("genBtn").disabled = false; $("genBtn").textContent = "Generate"; }
});

document.addEventListener("click", async (ev) => {
  const c = ev.target.closest("[data-copy]");
  if (c) {
    try { await navigator.clipboard.writeText(c.dataset.copy); toast("Copied"); }
    catch { toast("Copy blocked by the browser. Select the key and copy manually."); }
    return;
  }
  const r = ev.target.closest("[data-revoke]");
  if (r && confirm(`Revoke ${r.dataset.revoke}? The user loses access on their next check.`)) {
    r.disabled = true;
    try { await updateDoc(doc(db, "licenses", r.dataset.revoke), { status: "revoked", revokedAt: serverTimestamp() }); toast("Key revoked"); }
    catch (e) { toast(errMsg(e)); r.disabled = false; }
  }
});
$("tabs").addEventListener("click", (ev) => {
  const b = ev.target.closest("button"); if (!b) return;
  filter = b.dataset.f;
  [...$("tabs").children].forEach((x) => x.classList.toggle("on", x === b));
  render();
});
$("search").addEventListener("input", render);
setInterval(() => { if (!$("app").hidden) render(); }, 1000);

function render() {
  const n = { total: licenses.length, unused: 0, active: 0, expired: 0, revoked: 0 };
  licenses.forEach((l) => n[statusOf(l)]++);
  $("stats").innerHTML = [["Total", n.total], ["Unused", n.unused], ["Active", n.active], ["Expired", n.expired], ["Revoked", n.revoked]]
    .map(([k, v]) => `<div class="stat"><b>${v}</b><span>${k}</span></div>`).join("");
  const q = $("search").value.trim().toUpperCase();
  const rows = licenses.filter((l) => (filter === "all" || statusOf(l) === filter) &&
    (!q || l.key.includes(q) || (l.deviceId || "").toUpperCase().includes(q)));
  $("keysEmpty").hidden = rows.length > 0;
  $("keysBody").innerHTML = rows.slice(0, 300).map((l) => {
    const st = statusOf(l);
    return `<tr><td class="key">${esc(l.key)}</td><td>${esc(l.durationLabel)}</td>
      <td><span class="pill ${st}">${st}</span></td><td>${remaining(l)}</td>
      <td>${esc((l.deviceId || "—").slice(0, 10))}</td>
      <td><button class="btn sm ghost" data-copy="${esc(l.key)}">Copy</button>
      ${st === "revoked" ? "" : `<button class="btn sm danger" data-revoke="${esc(l.key)}">Revoke</button>`}</td></tr>`;
  }).join("");
}
function renderHistory(rows) {
  $("histEmpty").hidden = rows.length > 0;
  $("histBody").innerHTML = rows.map((a) => `<tr><td>${fmt(a.activatedAtMs)}</td><td class="key">${esc(a.key)}</td>
    <td>${esc(a.durationLabel)}</td><td>${esc((a.deviceId || "").slice(0, 10))}</td><td>${fmt(a.expiresAtMs)}</td></tr>`).join("");
}
