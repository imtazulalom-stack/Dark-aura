// Public web config (not a secret). Security comes from Firestore rules + Cloud Functions.
export const firebaseConfig = {
  apiKey: "AIzaSyAGCOzMYXuu09G7SIDV7rjcDKBCD2eSTCQ",
  authDomain: "dark-aura-5e1d9.firebaseapp.com",
  projectId: "dark-aura-5e1d9",
  storageBucket: "dark-aura-5e1d9.firebasestorage.app",
  messagingSenderId: "491155078817",
  appId: "1:491155078817:web:8ad57e482cc74c79337ae0"
};
