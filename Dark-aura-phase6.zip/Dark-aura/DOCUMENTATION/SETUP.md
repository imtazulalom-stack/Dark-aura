# Setup (FREE Spark plan, no Cloud Functions)

Design: Firestore Security Rules enforce everything server-side.
- Start/expiry of a key are forced to Firestore SERVER time (request.time); users cannot set them.
- A key can be activated once (rule only allows unused -> active).
- Only the admin email can create/list/revoke keys.
- Cloud Functions version is kept in OPTIONAL-PAID/ (needs Blaze plan). Not used.

Steps (all from the Firebase console, phone is fine):
1. Authentication > Sign-in method: enable Email/Password (done) and Anonymous.
2. Firestore > Rules: paste FIREBASE/firestore.rules, Publish.
3. Upload this repo to GitHub, then Settings > Pages > Deploy from branch main, folder / (root; index.html redirects to ADMIN-WEBSITE).
4. Authentication > Settings > Authorized domains: add <username>.github.io.
5. Open the Pages link, sign in with the admin email, generate keys.
Optional hardening: Authentication > Settings > User actions: disable "Enable create (sign-up)".
