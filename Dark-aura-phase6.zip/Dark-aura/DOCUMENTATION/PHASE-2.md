# Phase 2 - Animated splash screen

What you should see after installing:
1. Black cyber background (blue/purple glow, faint grid, slow scan line).
2. AURA X logo pops in: spinning neon ring, glowing hexagon, letter A.
3. "AURA X" title + "PRECISION TRAINING PANEL" fade in.
4. Progress bar fills 0 -> 100% in about 3 seconds.
5. Screen fades into a temporary "ACTIVATION" placeholder (real screen = Phase 3).

New files (ANDROID-APP/app/src/main/java/com/aurax/panel/):
- ui/components/AuraLogo.kt, CyberBackground.kt, NeonProgressBar.kt
- ui/splash/SplashScreen.kt
- ui/activation/ActivationScreen.kt (placeholder)
- navigation/Routes.kt, AuraNavHost.kt
- MainActivity.kt (now starts the navigation)

Build on phone: upload Dark-aura-phase2.zip to the GitHub repo, wait for Actions, download the APK.
