# Phase 3 - Activation screen (UI)

Fixed: "ACTIVATION" title was black on black (default text color). Theme now sets light text everywhere.

What works in this phase:
- Key field: AURA- is added automatically (shown as a hint under the field), auto-uppercases, auto-inserts dashes (XXXX-XXXX-XXXX-XXXX),
  accepts a full pasted key (with or without AURA- and dashes), Paste button reads the clipboard.
- Validation: empty / incomplete key, and invalid characters (I, O, 0, 1 never appear in keys).
- ACTIVATE button: disabled when empty, press animation, loading spinner, keyboard "Done" also submits.
- Error banner (red) for every case: invalid format, invalid characters, not found, already used,
  revoked, expired, no internet, unknown.

What does NOT work yet (honest):
- Real server check. In this phase a valid-looking key always shows the yellow message
  "Server connection is added in Phase 7". Nothing is activated. This is on purpose.

Files:
- data/license/ActivationRepository.kt, LicenseKey.kt
- ui/activation/ActivationScreen.kt, ActivationViewModel.kt, KeyVisualTransformation.kt
- ui/components/GlassCard.kt, NeonButton.kt
- ui/theme/Theme.kt (text color fix), navigation/AuraNavHost.kt, AndroidManifest.xml (adjustResize)

Test on phone:
1. Type 3 characters, tap ACTIVATE -> red "Enter the full key" message.
2. Type/paste 16 characters like ABCDEFGHJKLMNPQR -> yellow "Server connection..." message after a short spinner.
3. Type a key containing 0 or O -> red "invalid characters" message.
4. Paste "AURA-ABCD-EFGH-JKLM-NPQR" -> dashes and prefix handled automatically.
