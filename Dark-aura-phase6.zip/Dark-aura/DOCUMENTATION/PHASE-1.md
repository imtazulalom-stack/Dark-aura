# Phase 1 - Open and run the Android project

You need: Android Studio (Ladybug 2024.2 or newer), internet for the first Gradle sync.

1. Open Android Studio > Open > select the ANDROID-APP folder (not the Dark-aura folder).
2. Wait for "Gradle sync" to finish (first time can take 5-10 minutes).
   Android Studio downloads Gradle 8.9 automatically from gradle-wrapper.properties.
3. If asked, install Android SDK Platform 35 (SDK Manager).
4. Press Run (green triangle) on an emulator or a phone with USB debugging.
5. Expected result: black screen, "AURA X" in blue-to-purple gradient,
   and the text "Phase 1: project setup complete".

If sync fails, copy the first red error line and send it to me.

Note: google-services.json is NOT needed yet. It is added in Phase 7.
