# Phase 4 - Game selection

What works:
- 3 animated cards: Free Fire Global, Free Fire India, Free Fire MAX.
  Cards slide in one by one, shrink slightly when pressed, glow + check icon + "SELECTED" label when chosen.
- CONTINUE is disabled until one is selected. The choice is saved on the phone and pre-selected next time.
- Temporary Home screen shows the selected game. Its CHANGE GAME button returns to the selection screen.

Placeholders / honest notes:
- Logos are neutral "FF" monogram placeholders, NOT the official Free Fire artwork.
  You can replace them later with your own images.
- "Separate settings and sensitivity profile per game": the game is saved with an id
  (global / india / max). The profiles themselves are stored per id in Phase 6.

DEV ONLY button:
- The activation screen shows "DEV ONLY: skip activation (debug build)" so you can test Phase 4-6
  before the server exists (Phase 7). It appears only when BuildConfig.DEBUG is true.
  The final release APK (Phase 10) does not show it and cannot skip activation.

Files:
- data/game/GameVersion.kt, GamePreferences.kt
- ui/games/GameSelectionScreen.kt, GameCard.kt, GameSelectionViewModel.kt
- ui/home/HomePlaceholderScreen.kt (temporary)
- navigation/Routes.kt, AuraNavHost.kt; ui/activation/ActivationScreen.kt (debug skip)
- app/build.gradle.kts (buildConfig = true, version 0.4.0)

Test:
1. Open app > wait for splash > Activation screen > tap the yellow DEV ONLY text.
2. Game selection: cards slide in. CONTINUE is greyed out.
3. Tap a card: glow + SELECTED. Tap CONTINUE: Home shows the game name.
4. CHANGE GAME: the previous choice is already highlighted. Pick another, CONTINUE: Home updates.
5. Close the app fully and reopen > splash > skip > the last choice is pre-selected.
