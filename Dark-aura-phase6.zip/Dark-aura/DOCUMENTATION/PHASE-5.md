# Phase 5 - Main dashboard + bottom navigation

Bottom bar (all 4 tabs work): Home, Features, Statistics, Profile.

HOME (dashboard)
- AURA X branding, bell (opens Notifications dialog), gear (opens Settings page).
- Profile card: avatar initial + your display name.
- Activation card: status chip + remaining-time counter.
- Game version card with a working CHANGE button.
- Quick Access tiles for the 5 modules.
- App version at the bottom.

FEATURES: full list of the 5 modules (tap any).
STATISTICS: empty state (no data exists yet).
PROFILE: edit display name (2-20 chars, saved on the phone), change game, version, open Settings.

HONEST STATUS (what is real and what is not yet)
- REAL: navigation, display name, game selection/saving, version, notifications dialog (empty).
- NOT YET: Activation card shows "DEV MODE" and "--:--:--". There is no server check yet, so the app
  cannot know a real license or countdown. Phase 7 fills this in. The Active/Expired layouts are already
  written but cannot appear until Phase 7.
- NOT YET: the 5 modules and Settings open a "COMING IN PHASE 6" page (with a working Back button).
- NOT YET: Notifications have no messages (they will come from Firebase later).

Test:
1. Skip activation (DEV ONLY), choose a game, Continue -> dashboard.
2. Tap each bottom tab. Tap bell, gear, CHANGE, and every Quick Access tile; Back returns.
3. Profile: type a name, SAVE NAME -> "Saved"; go to Home: the greeting shows the new name.
4. Close and reopen the app: name and game are remembered.

New/changed files (ANDROID-APP/app/src/main/java/com/aurax/panel/):
- ui/main/MainScreen.kt, MainViewModel.kt
- ui/home/DashboardScreen.kt (replaces the temporary placeholder)
- ui/features/FeatureModule.kt, ModuleCard.kt, FeaturesScreen.kt, ComingSoonScreen.kt
- ui/stats/StatisticsScreen.kt, ui/profile/ProfileScreen.kt
- ui/components/StatusChip.kt, PlaceholderContent.kt, AuraTextFieldColors.kt
- data/profile/ProfilePreferences.kt, data/license/LicenseDisplay.kt
- navigation/Routes.kt, AuraNavHost.kt; build.gradle.kts (version 0.5.0)
