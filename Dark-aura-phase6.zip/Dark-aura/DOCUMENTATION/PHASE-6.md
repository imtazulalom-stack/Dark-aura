# Phase 6 - Practice modules, Statistics, Settings

All 6 modules and Settings now work. Everything runs offline inside the app and never touches any game.

- Aim Practice: moving round targets, 30 s. Score, accuracy, average reaction. Misses cost points.
- Headshot Practice: moving figures. Head zone = headshot (150 pts), body = 40 pts. Shows headshot accuracy.
- Reaction Test: 5 rounds, random wait, early-tap detection, average + best.
- Sensitivity Guide: your phone's real resolution/dpi, DPI explanation, 3 generic starting profiles
  (NOT official values), 6 custom sliders saved on the phone.
- Leaderboard: your personal top 10 per mode. Local only (no online ranking exists).
- Custom Interface: target color, target size, vibration, sound. Saved automatically.
- Statistics: real totals, averages, bests, accuracy bar chart, recent runs.
- Settings: clear history, version, privacy policy, terms. Log out arrives with Phase 7.

NOT included on purpose: auto-aim, auto-headshot, enemy position/location, memory or game modification.

Still NOT real: license status/countdown (Phase 7). Firebase package: the Firebase Android app was registered as
com.aurax.trainer, but this app uses com.aurax.panel. Before Phase 7 we must make them match.

Test: Features > open each module; play a run; check Statistics, Leaderboard; toggle Custom Interface; Settings > Clear history.
Version 0.6.0.
