// Grants the admin custom claim to an existing Firebase Auth user.
// Usage (from FIREBASE/functions after `npm install`):
//   GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccount.json node ../scripts/set-admin.js you@example.com
// Keep the service-account file on YOUR machine. Never commit it.
const { initializeApp } = require('../functions/node_modules/firebase-admin/app');
const { getAuth } = require('../functions/node_modules/firebase-admin/auth');
(async () => {
  const email = process.argv[2];
  if (!email) { console.error('Usage: node set-admin.js <email>'); process.exit(1); }
  initializeApp();
  const user = await getAuth().getUserByEmail(email);
  await getAuth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`Admin claim set for ${email}. Sign out and in again to refresh the token.`);
})().catch((e) => { console.error(e.message); process.exit(1); });
