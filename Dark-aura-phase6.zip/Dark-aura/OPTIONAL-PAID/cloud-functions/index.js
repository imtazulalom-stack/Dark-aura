'use strict';
const crypto = require('crypto');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

const OPTS = { region: 'us-central1', maxInstances: 10 };
const SEC = 1000;
const DURATIONS = {
  '15m': { ms: 15 * 60 * SEC, label: '15 Minutes' },
  '30m': { ms: 30 * 60 * SEC, label: '30 Minutes' },
  '1h': { ms: 3600 * SEC, label: '1 Hour' },
  '3h': { ms: 3 * 3600 * SEC, label: '3 Hours' },
  '6h': { ms: 6 * 3600 * SEC, label: '6 Hours' },
  '12h': { ms: 12 * 3600 * SEC, label: '12 Hours' },
  '24h': { ms: 24 * 3600 * SEC, label: '24 Hours' },
  '7d': { ms: 7 * 86400 * SEC, label: '7 Days' },
  '30d': { ms: 30 * 86400 * SEC, label: '30 Days' },
};
const KEY_RE = /^AURA(-[A-HJ-NP-Z2-9]{4}){4}$/;
const DEVICE_RE = /^[A-Za-z0-9_-]{8,128}$/;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const MAX_FAILS = 10;
const FAIL_WINDOW_MS = 60 * 60 * SEC;

function requireAdmin(req) {
  if (!req.auth || req.auth.token.admin !== true) {
    throw new HttpsError('permission-denied', 'Admin access required.');
  }
}
function cleanKey(v) {
  const k = String(v || '').trim().toUpperCase();
  if (!KEY_RE.test(k)) throw new HttpsError('invalid-argument', 'Invalid key format.');
  return k;
}
function cleanDevice(v) {
  const d = String(v || '').trim();
  if (!DEVICE_RE.test(d)) throw new HttpsError('invalid-argument', 'Invalid device id.');
  return d;
}
function newKey() {
  const bytes = crypto.randomBytes(16);
  let out = '';
  for (let i = 0; i < 16; i++) out += ALPHABET[bytes[i] % 32];
  return 'AURA-' + out.match(/.{4}/g).join('-');
}
function view(d, now) {
  let status = d.status;
  if (status === 'active' && d.expiresAtMs <= now) status = 'expired';
  return {
    status,
    durationLabel: d.durationLabel,
    activatedAtMs: d.activatedAtMs || null,
    expiresAtMs: d.expiresAtMs || null,
    remainingSeconds: status === 'active' ? Math.max(0, Math.floor((d.expiresAtMs - now) / SEC)) : 0,
    serverNowMs: now,
  };
}
async function checkBlocked(deviceId) {
  const snap = await db.collection('attempts').doc(deviceId).get();
  if (!snap.exists) return;
  const a = snap.data();
  if (a.count >= MAX_FAILS && Date.now() - a.firstMs < FAIL_WINDOW_MS) {
    throw new HttpsError('resource-exhausted', 'Too many failed attempts. Try again later.');
  }
}
async function recordFail(deviceId) {
  const ref = db.collection('attempts').doc(deviceId);
  await db.runTransaction(async (t) => {
    const s = await t.get(ref);
    const now = Date.now();
    if (!s.exists || now - s.data().firstMs >= FAIL_WINDOW_MS) t.set(ref, { count: 1, firstMs: now });
    else t.update(ref, { count: FieldValue.increment(1) });
  });
}

exports.generateLicense = onCall(OPTS, async (req) => {
  requireAdmin(req);
  const dur = DURATIONS[req.data && req.data.duration];
  if (!dur) throw new HttpsError('invalid-argument', 'Unknown duration.');
  const count = Number(req.data.count || 1);
  if (!Number.isInteger(count) || count < 1 || count > 50) {
    throw new HttpsError('invalid-argument', 'Count must be 1-50.');
  }
  const keys = [];
  while (keys.length < count) {
    const key = newKey();
    try {
      await db.collection('licenses').doc(key).create({
        key,
        duration: req.data.duration,
        durationMs: dur.ms,
        durationLabel: dur.label,
        status: 'unused',
        createdAtMs: Date.now(),
        createdAt: FieldValue.serverTimestamp(),
        createdBy: req.auth.uid,
        createdByEmail: req.auth.token.email || null,
      });
      keys.push(key);
    } catch (e) {
      if (e.code !== 6 && e.code !== 'already-exists') throw new HttpsError('internal', 'Could not create key.');
    }
  }
  return { keys, durationLabel: dur.label };
});

exports.activateLicense = onCall(OPTS, async (req) => {
  const key = cleanKey(req.data && req.data.key);
  const deviceId = cleanDevice(req.data && req.data.deviceId);
  await checkBlocked(deviceId);
  const ref = db.collection('licenses').doc(key);

  let result;
  try {
    result = await db.runTransaction(async (t) => {
      const snap = await t.get(ref);
      if (!snap.exists) throw new HttpsError('not-found', 'Activation key not found.');
      const d = snap.data();
      const now = Date.now();
      if (d.status === 'revoked') throw new HttpsError('permission-denied', 'This key has been revoked.');
      if (d.status === 'unused') {
        const upd = {
          status: 'active',
          deviceId,
          activatedAtMs: now,
          expiresAtMs: now + d.durationMs,
          activatedAt: FieldValue.serverTimestamp(),
        };
        t.update(ref, upd);
        t.create(db.collection('activations').doc(), {
          key, deviceId, durationLabel: d.durationLabel,
          activatedAtMs: now, expiresAtMs: upd.expiresAtMs,
          activatedAt: FieldValue.serverTimestamp(),
        });
        return view({ ...d, ...upd }, now);
      }
      if (d.deviceId !== deviceId) throw new HttpsError('already-exists', 'This key has already been used.');
      return view(d, now);
    });
  } catch (e) {
    if (e instanceof HttpsError && ['not-found', 'permission-denied', 'already-exists'].includes(e.code)) {
      await recordFail(deviceId);
    }
    throw e;
  }
  if (result.status === 'expired') throw new HttpsError('failed-precondition', 'This key has expired.');
  return result;
});

exports.verifyLicense = onCall(OPTS, async (req) => {
  const key = cleanKey(req.data && req.data.key);
  const deviceId = cleanDevice(req.data && req.data.deviceId);
  await checkBlocked(deviceId);
  const snap = await db.collection('licenses').doc(key).get();
  const now = Date.now();
  if (!snap.exists) { await recordFail(deviceId); return { valid: false, status: 'invalid', serverNowMs: now }; }
  const d = snap.data();
  if (d.status === 'unused' || d.deviceId !== deviceId) {
    await recordFail(deviceId);
    return { valid: false, status: 'invalid', serverNowMs: now };
  }
  const v = view(d, now);
  return { valid: v.status === 'active', ...v };
});

exports.revokeLicense = onCall(OPTS, async (req) => {
  requireAdmin(req);
  const key = cleanKey(req.data && req.data.key);
  const ref = db.collection('licenses').doc(key);
  await db.runTransaction(async (t) => {
    const s = await t.get(ref);
    if (!s.exists) throw new HttpsError('not-found', 'Key not found.');
    if (s.data().status === 'revoked') throw new HttpsError('failed-precondition', 'Already revoked.');
    t.update(ref, {
      status: 'revoked',
      revokedAtMs: Date.now(),
      revokedAt: FieldValue.serverTimestamp(),
      revokedBy: req.auth.uid,
    });
  });
  return { ok: true };
});

exports.getLicenseStatus = onCall(OPTS, async (req) => {
  requireAdmin(req);
  const key = cleanKey(req.data && req.data.key);
  const snap = await db.collection('licenses').doc(key).get();
  if (!snap.exists) throw new HttpsError('not-found', 'Key not found.');
  const d = snap.data();
  return { key, deviceId: d.deviceId || null, revokedAtMs: d.revokedAtMs || null, createdAtMs: d.createdAtMs, ...view(d, Date.now()) };
});
