package com.aurax.panel.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.VibrationEffect
import android.os.Vibrator
import com.aurax.panel.data.settings.AppSettings

/** Short vibration / beep when you hit or miss. Respects the Custom Interface switches. */
class Feedback(context: Context, private val settings: AppSettings) {
    private val vibrator: Vibrator? = context.applicationContext.getSystemService(Vibrator::class.java)
    private var tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    } catch (e: Exception) {
        null
    }

    fun hit() {
        if (settings.vibration) vibrate(18)
        if (settings.sound) tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 40)
    }

    fun miss() {
        if (settings.vibration) vibrate(8)
    }

    private fun vibrate(ms: Long) {
        try {
            vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // Vibration is optional; ignore failures.
        }
    }

    fun release() {
        tone?.release()
        tone = null
    }
}
