package com.aurax.panel.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurax.panel.ui.theme.AuraBlack
import com.aurax.panel.ui.theme.DeepPurple
import com.aurax.panel.ui.theme.ElectricBlue
import com.aurax.panel.ui.theme.NeonBlue

/** Black cyberpunk background: blue/purple glows, faint grid and a slow scan line. */
@Composable
fun CyberBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "bg")
    val scan by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)),
        label = "scan"
    )

    Box(modifier = modifier.fillMaxSize().background(AuraBlack)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(ElectricBlue.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.10f),
                    radius = size.width * 0.9f
                )
            )
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(DeepPurple.copy(alpha = 0.28f), Color.Transparent),
                    center = Offset(size.width * 0.90f, size.height * 0.95f),
                    radius = size.width * 1.0f
                )
            )

            val step = 48.dp.toPx()
            var x = 0f
            while (x <= size.width) {
                drawLine(NeonBlue.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height), 1f)
                x += step
            }
            var y = 0f
            while (y <= size.height) {
                drawLine(NeonBlue.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y), 1f)
                y += step
            }

            val band = 120.dp.toPx()
            val sy = size.height * scan
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, NeonBlue.copy(alpha = 0.10f), Color.Transparent),
                    startY = sy - band,
                    endY = sy + band
                ),
                topLeft = Offset(0f, sy - band),
                size = Size(size.width, band * 2)
            )
        }
        content()
    }
}
