package com.aurax.panel.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurax.panel.ui.components.AuraLogo
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.components.NeonProgressBar
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Animated splash: logo pops in, title fades in, progress bar fills, then onFinished(). */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val logoAlpha = remember { Animatable(0f) }
    val logoScale = remember { Animatable(0.6f) }
    val textAlpha = remember { Animatable(0f) }
    val currentOnFinished by rememberUpdatedState(onFinished)

    LaunchedEffect(Unit) {
        launch { logoAlpha.animateTo(1f, tween(800)) }
        launch {
            logoScale.animateTo(
                1f,
                spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)
            )
        }
        launch {
            delay(500)
            textAlpha.animateTo(1f, tween(700))
        }
        progress.animateTo(
            1f,
            tween(3000, easing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f))
        )
        delay(300)
        currentOnFinished()
    }

    val status = when {
        progress.value < 0.35f -> "Initializing…"
        progress.value < 0.75f -> "Loading modules…"
        progress.value < 1f -> "Almost ready…"
        else -> "Ready"
    }

    CyberBackground {
        Column(
            modifier = Modifier.fillMaxSize().systemBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.weight(1f))

            AuraLogo(
                logoSize = 170.dp,
                modifier = Modifier.graphicsLayer {
                    alpha = logoAlpha.value
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                }
            )

            Spacer(Modifier.height(28.dp))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value }
            ) {
                Text(
                    text = "AURA X",
                    style = MaterialTheme.typography.displayLarge.copy(
                        brush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))
                    )
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "PRECISION TRAINING PANEL",
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 3.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.weight(1f))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 40.dp)
                    .padding(bottom = 48.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${(progress.value * 100).toInt()}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonBlue
                    )
                }
                Spacer(Modifier.height(10.dp))
                NeonProgressBar(
                    progress = progress.value,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
