package com.aurax.panel.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurax.panel.ui.theme.ElectricBlue
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import kotlin.math.cos
import kotlin.math.sin

/**
 * AURA X logo drawn fully in code (no image files):
 * spinning neon ring + glowing hexagon + letter "A".
 */
@Composable
fun AuraLogo(modifier: Modifier = Modifier, logoSize: Dp = 160.dp) {
    val transition = rememberInfiniteTransition(label = "logo")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)),
        label = "ring"
    )
    val glow by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "glow"
    )

    Canvas(modifier = modifier.size(logoSize)) {
        val w = this.size.minDimension
        val r = w / 2f
        val c = center

        // Faint static ring + spinning bright arc
        drawCircle(
            color = NeonBlue.copy(alpha = 0.12f),
            radius = r * 0.94f,
            center = c,
            style = Stroke(width = w * 0.008f)
        )
        val ringBrush = Brush.sweepGradient(
            0f to Color.Transparent,
            0.5f to NeonBlue,
            0.85f to NeonPurple,
            1f to Color.Transparent,
            center = c
        )
        rotate(degrees = rotation, pivot = c) {
            drawCircle(
                brush = ringBrush,
                radius = r * 0.94f,
                center = c,
                style = Stroke(width = w * 0.022f, cap = StrokeCap.Round)
            )
        }

        // Hexagon
        val hexR = r * 0.66f
        val hex = Path().apply {
            for (i in 0 until 6) {
                val a = Math.toRadians((60 * i - 90).toDouble())
                val x = c.x + hexR * cos(a).toFloat()
                val y = c.y + hexR * sin(a).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        val hexBrush = Brush.linearGradient(
            listOf(NeonBlue, ElectricBlue, NeonPurple),
            start = androidx.compose.ui.geometry.Offset(0f, 0f),
            end = androidx.compose.ui.geometry.Offset(w, w)
        )
        glowPath(hex, hexBrush, w * 0.022f, glow)

        // Letter A
        val aH = w * 0.21f
        val aW = w * 0.16f
        val letter = Path().apply {
            moveTo(c.x - aW, c.y + aH)
            lineTo(c.x, c.y - aH)
            lineTo(c.x + aW, c.y + aH)
        }
        val bar = Path().apply {
            moveTo(c.x - aW * 0.5f, c.y + aH * 0.3f)
            lineTo(c.x + aW * 0.5f, c.y + aH * 0.3f)
        }
        glowPath(letter, SolidBlue, w * 0.03f, glow)
        glowPath(bar, SolidPurple, w * 0.03f, glow)
    }
}

private val SolidBlue = Brush.linearGradient(listOf(NeonBlue, NeonBlue))
private val SolidPurple = Brush.linearGradient(listOf(NeonPurple, NeonPurple))

/** Draws a path with a soft neon glow (wide faint strokes) and a crisp line on top. */
private fun DrawScope.glowPath(path: Path, brush: Brush, width: Float, glow: Float) {
    for (i in 3 downTo 1) {
        drawPath(
            path = path,
            brush = brush,
            alpha = 0.10f * glow,
            style = Stroke(
                width = width + i * width * 0.9f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
    drawPath(
        path = path,
        brush = brush,
        style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}
