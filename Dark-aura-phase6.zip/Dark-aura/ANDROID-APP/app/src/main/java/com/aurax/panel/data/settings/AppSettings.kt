package com.aurax.panel.data.settings

import android.content.Context
import androidx.compose.ui.graphics.Color
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusError
import com.aurax.panel.ui.theme.StatusSuccess

val TARGET_COLORS: List<Pair<String, Color>> = listOf(
    "Blue" to NeonBlue,
    "Purple" to NeonPurple,
    "Green" to StatusSuccess,
    "Red" to StatusError
)

val TARGET_SIZES: List<String> = listOf("Small", "Medium", "Large")

/** Local app settings (this phone only). */
class AppSettings(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aurax_settings", Context.MODE_PRIVATE)

    var vibration: Boolean
        get() = prefs.getBoolean("vibration", true)
        set(v) = prefs.edit().putBoolean("vibration", v).apply()

    var sound: Boolean
        get() = prefs.getBoolean("sound", true)
        set(v) = prefs.edit().putBoolean("sound", v).apply()

    /** 0 = small, 1 = medium, 2 = large */
    var targetSize: Int
        get() = prefs.getInt("target_size", 1).coerceIn(0, 2)
        set(v) = prefs.edit().putInt("target_size", v.coerceIn(0, 2)).apply()

    var targetColor: Int
        get() = prefs.getInt("target_color", 0).coerceIn(0, TARGET_COLORS.lastIndex)
        set(v) = prefs.edit().putInt("target_color", v.coerceIn(0, TARGET_COLORS.lastIndex)).apply()

    fun getSens(key: String, default: Int = 50): Int =
        prefs.getInt("sens_$key", default).coerceIn(0, 100)

    fun setSens(key: String, value: Int) {
        prefs.edit().putInt("sens_$key", value.coerceIn(0, 100)).apply()
    }
}
