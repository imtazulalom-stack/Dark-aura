package com.aurax.panel.ui.components

import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.StatusError
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

@Composable
fun auraTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    errorTextColor = TextPrimary,
    focusedBorderColor = NeonBlue,
    unfocusedBorderColor = TextMuted.copy(alpha = 0.4f),
    errorBorderColor = StatusError,
    focusedLabelColor = NeonBlue,
    unfocusedLabelColor = TextMuted,
    errorLabelColor = StatusError,
    cursorColor = NeonBlue,
    errorCursorColor = StatusError,
    focusedSupportingTextColor = TextMuted,
    unfocusedSupportingTextColor = TextMuted,
    errorSupportingTextColor = StatusError
)
