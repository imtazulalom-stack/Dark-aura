package com.aurax.panel.ui.main

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.features.FeatureModule
import com.aurax.panel.ui.features.FeaturesScreen
import com.aurax.panel.ui.home.DashboardScreen
import com.aurax.panel.ui.profile.ProfileScreen
import com.aurax.panel.ui.stats.StatisticsScreen
import com.aurax.panel.ui.theme.AuraSurface
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.TextMuted

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    HOME("tab_home", "Home", Icons.Filled.Home),
    FEATURES("tab_features", "Features", Icons.Filled.Apps),
    STATS("tab_stats", "Statistics", Icons.Filled.BarChart),
    PROFILE("tab_profile", "Profile", Icons.Filled.Person)
}

/** Main area: bottom navigation (Home, Features, Statistics, Profile). */
@Composable
fun MainScreen(
    onOpenModule: (FeatureModule) -> Unit,
    onOpenSettings: () -> Unit,
    onChangeGame: () -> Unit,
    viewModel: MainViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // Re-read saved values every time this screen becomes visible (e.g. after "Change game").
    LifecycleResumeEffect(Unit) {
        viewModel.reload()
        onPauseOrDispose { }
    }

    val tabNav = rememberNavController()
    val backStack by tabNav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    CyberBackground {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = AuraSurface.copy(alpha = 0.94f)) {
                    Tab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                tabNav.navigate(tab.route) {
                                    popUpTo(tabNav.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonBlue,
                                selectedTextColor = NeonBlue,
                                indicatorColor = NeonBlue.copy(alpha = 0.15f),
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            }
        ) { inner ->
            NavHost(
                navController = tabNav,
                startDestination = Tab.HOME.route,
                modifier = Modifier.padding(inner),
                enterTransition = { fadeIn(tween(250)) },
                exitTransition = { fadeOut(tween(250)) }
            ) {
                composable(Tab.HOME.route) {
                    DashboardScreen(
                        state = state,
                        onOpenModule = onOpenModule,
                        onOpenSettings = onOpenSettings,
                        onChangeGame = onChangeGame
                    )
                }
                composable(Tab.FEATURES.route) { FeaturesScreen(onOpenModule = onOpenModule) }
                composable(Tab.STATS.route) { StatisticsScreen() }
                composable(Tab.PROFILE.route) {
                    ProfileScreen(
                        state = state,
                        onSaveName = viewModel::saveName,
                        onChangeGame = onChangeGame,
                        onOpenSettings = onOpenSettings
                    )
                }
            }
        }
    }
}
