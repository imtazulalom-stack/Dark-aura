package com.aurax.panel.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.aurax.panel.data.practice.PracticeStore
import com.aurax.panel.data.practice.PracticeType
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.PlaceholderContent
import com.aurax.panel.ui.practice.SectionTitle
import com.aurax.panel.ui.practice.StatTile
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Real statistics from the practice history stored on this phone. */
@Composable
fun StatisticsScreen() {
    val context = LocalContext.current
    val store = remember { PracticeStore(context) }
    var version by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        version++
        onPauseOrDispose { }
    }
    val sessions = remember(version) { store.all() }

    if (sessions.isEmpty()) {
        PlaceholderContent(
            icon = Icons.Filled.BarChart,
            title = "STATISTICS",
            message = "No practice sessions yet. Play Aim Practice, Headshot Practice or the Reaction Test and your results appear here."
        )
        return
    }

    val aimLike = sessions.filter { it.type != PracticeType.REACTION }
    val reaction = sessions.filter { it.type == PracticeType.REACTION && it.reactionMs >= 0 }
    val avgAcc = if (aimLike.isNotEmpty()) aimLike.sumOf { it.accuracy } / aimLike.size else 0
    val headSessions = sessions.filter { it.headshotAcc >= 0 }
    val avgHead = if (headSessions.isNotEmpty()) headSessions.sumOf { it.headshotAcc } / headSessions.size else 0
    val bestAim = sessions.filter { it.type == PracticeType.AIM }.maxOfOrNull { it.score } ?: 0
    val bestHead = sessions.filter { it.type == PracticeType.HEADSHOT }.maxOfOrNull { it.score } ?: 0
    val bestReaction = reaction.minOfOrNull { it.reactionMs }
    val avgReaction = if (reaction.isNotEmpty()) reaction.sumOf { it.reactionMs } / reaction.size else null
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    val chartData = aimLike.takeLast(10).map { it.accuracy }

    Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("STATISTICS", style = MaterialTheme.typography.headlineMedium)
        SectionTitle("Overview")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                StatTile("RUNS", "${sessions.size}", Modifier.weight(1f))
                StatTile("AVG ACCURACY", "$avgAcc%", Modifier.weight(1f), StatusSuccess)
                StatTile("AVG HEADSHOT", "$avgHead%", Modifier.weight(1f), NeonPurple)
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                StatTile("BEST AIM", "$bestAim", Modifier.weight(1f))
                StatTile("BEST HEAD", "$bestHead", Modifier.weight(1f), NeonPurple)
                StatTile("BEST REACTION", bestReaction?.let { "$it ms" } ?: "--", Modifier.weight(1f), StatusSuccess)
            }
            if (avgReaction != null) {
                Spacer(Modifier.height(10.dp))
                Text("Average reaction: $avgReaction ms", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (chartData.size >= 2) {
            SectionTitle("Accuracy, last ${chartData.size} runs")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                    val gap = 6.dp.toPx()
                    val barW = (size.width - gap * (chartData.size - 1)) / chartData.size
                    chartData.forEachIndexed { i, acc ->
                        val h = size.height * (acc.coerceIn(0, 100) / 100f)
                        drawRect(
                            color = NeonBlue,
                            topLeft = Offset(i * (barW + gap), size.height - h),
                            size = Size(barW, h)
                        )
                    }
                }
            }
        }

        SectionTitle("Recent runs")
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            sessions.takeLast(8).reversed().forEach { s ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(s.type.label.substringBefore(" "), color = NeonBlue, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (s.type == PracticeType.REACTION) "${s.reactionMs} ms" else "${s.score} pts  ${s.accuracy}%",
                        color = TextPrimary, style = MaterialTheme.typography.bodyMedium
                    )
                    Text(fmt.format(Date(s.timeMs)), color = TextMuted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
