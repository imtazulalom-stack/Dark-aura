package com.aurax.panel.ui.theme

import androidx.compose.ui.graphics.Color

// Base
val AuraBlack = Color(0xFF05060A)
val AuraSurface = Color(0xFF0D0F1A)
val AuraSurfaceHigh = Color(0xFF151933)

// Neon accents
val NeonBlue = Color(0xFF00D4FF)
val ElectricBlue = Color(0xFF2979FF)
val NeonPurple = Color(0xFF9D4DFF)
val DeepPurple = Color(0xFF6A1BFF)

// Text
val TextPrimary = Color(0xFFEAF0FF)
val TextMuted = Color(0xFF8A93B2)

// Status
val StatusError = Color(0xFFFF4D6D)
val StatusSuccess = Color(0xFF2EE6A6)
val StatusWarning = Color(0xFFFFB84D)
