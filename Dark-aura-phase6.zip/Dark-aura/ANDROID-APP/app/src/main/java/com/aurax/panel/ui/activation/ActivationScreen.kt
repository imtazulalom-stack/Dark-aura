package com.aurax.panel.ui.activation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurax.panel.data.license.ActivationError
import com.aurax.panel.ui.components.AuraLogo
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusError
import com.aurax.panel.ui.theme.StatusWarning
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

@Composable
fun ActivationScreen(
    onActivated: () -> Unit,
    onDebugSkip: (() -> Unit)? = null,
    viewModel: ActivationViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val currentOnActivated by rememberUpdatedState(onActivated)
    val focus = LocalFocusManager.current
    val clipboard = LocalClipboardManager.current
    val keyTransformation = remember { KeyVisualTransformation() }

    LaunchedEffect(state.activated) {
        if (state.activated) currentOnActivated()
    }

    val submit = {
        focus.clearFocus()
        viewModel.onActivateClicked()
    }

    CyberBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            AuraLogo(logoSize = 96.dp)
            Spacer(Modifier.height(14.dp))
            Text(
                text = "AURA X",
                style = MaterialTheme.typography.headlineMedium.copy(
                    letterSpacing = 6.sp,
                    brush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))
                )
            )
            Spacer(Modifier.height(32.dp))

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "ACTIVATE YOUR PANEL",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonBlue
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Enter the activation key you received from the AURA X admin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(20.dp))

                OutlinedTextField(
                    value = state.keyBody,
                    onValueChange = viewModel::onKeyChanged,
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !state.isLoading,
                    singleLine = true,
                    isError = state.error != null,
                    label = { Text("Activation key") },
                    supportingText = {
                        Text("AURA- is added automatically. You can paste the full key too.")
                    },
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                clipboard.getText()?.text?.let(viewModel::onKeyChanged)
                            },
                            enabled = !state.isLoading
                        ) {
                            Icon(Icons.Filled.ContentPaste, contentDescription = "Paste key")
                        }
                    },
                    visualTransformation = keyTransformation,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Characters,
                        keyboardType = KeyboardType.Ascii,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        errorTextColor = TextPrimary,
                        disabledTextColor = TextMuted,
                        focusedBorderColor = NeonBlue,
                        unfocusedBorderColor = TextMuted.copy(alpha = 0.4f),
                        errorBorderColor = StatusError,
                        focusedLabelColor = NeonBlue,
                        unfocusedLabelColor = TextMuted,
                        errorLabelColor = StatusError,
                        cursorColor = NeonBlue,
                        errorCursorColor = StatusError,
                        focusedTrailingIconColor = NeonBlue,
                        unfocusedTrailingIconColor = TextMuted,
                        focusedSupportingTextColor = TextMuted,
                        unfocusedSupportingTextColor = TextMuted
                    )
                )

                val error = state.error
                AnimatedVisibility(visible = error != null) {
                    if (error != null) {
                        Column {
                            Spacer(Modifier.height(14.dp))
                            ErrorBanner(error)
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                NeonButton(
                    text = "ACTIVATE",
                    onClick = { submit() },
                    enabled = state.keyBody.isNotEmpty(),
                    loading = state.isLoading
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                text = "Your license time starts the moment you activate.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
            if (onDebugSkip != null) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onDebugSkip) {
                    Text(
                        text = "DEV ONLY: skip activation (debug build)",
                        color = StatusWarning,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ErrorBanner(error: ActivationError) {
    val tint = if (error == ActivationError.NotConnected) StatusWarning else StatusError
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(tint.copy(alpha = 0.12f))
            .border(1.dp, tint.copy(alpha = 0.6f), shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Filled.ErrorOutline,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.size(10.dp))
        Text(
            text = error.message(),
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary
        )
    }
}

private fun ActivationError.message(): String = when (this) {
    ActivationError.InvalidFormat -> "Enter the full key: 16 characters after AURA-."
    ActivationError.InvalidCharacters -> "This key has invalid characters. Keys never contain I, O, 0 or 1."
    ActivationError.NotFound -> "Invalid activation key. Check it and try again."
    ActivationError.AlreadyUsed -> "This key has already been used."
    ActivationError.Revoked -> "This key was revoked by the administrator."
    ActivationError.Expired -> "This license has expired. Enter a new key."
    ActivationError.Network -> "No internet connection. Check your network and try again."
    ActivationError.NotConnected -> "Server connection is added in Phase 7, so keys cannot be verified yet."
    ActivationError.Unknown -> "Something went wrong. Please try again."
}
