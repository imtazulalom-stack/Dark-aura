package com.aurax.panel.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurax.panel.ui.theme.AuraSurfaceHigh
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple

/** Glowing blue-to-purple progress bar. progress is 0f..1f. */
@Composable
fun NeonProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    barHeight: Dp = 6.dp
) {
    Canvas(modifier = modifier.height(barHeight)) {
        val h = size.height
        drawRoundRect(
            color = AuraSurfaceHigh,
            size = size,
            cornerRadius = CornerRadius(h / 2f)
        )
        val fillW = size.width * progress.coerceIn(0f, 1f)
        if (fillW > 0f) {
            drawRoundRect(
                color = NeonBlue.copy(alpha = 0.25f),
                topLeft = Offset(0f, -h * 0.6f),
                size = Size(fillW, h * 2.2f),
                cornerRadius = CornerRadius(h * 1.1f)
            )
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(NeonBlue, NeonPurple),
                    startX = 0f,
                    endX = size.width
                ),
                size = Size(fillW, h),
                cornerRadius = CornerRadius(h / 2f)
            )
        }
    }
}
