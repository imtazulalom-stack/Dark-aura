package com.aurax.panel.ui.activation

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

/** Shows "ABCDEFGH..." as "ABCD-EFGH-..." while the stored text has no dashes. */
class KeyVisualTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val shown = buildString {
            raw.forEachIndexed { i, c ->
                if (i > 0 && i % 4 == 0) append('-')
                append(c)
            }
        }
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int =
                if (offset <= 0) 0 else offset + (offset - 1) / 4

            override fun transformedToOriginal(offset: Int): Int =
                (offset - listOf(4, 9, 14).count { it < offset }).coerceAtLeast(0)
        }
        return TransformedText(AnnotatedString(shown), mapping)
    }
}
