package com.aurax.panel.ui.features

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.components.PlaceholderContent

/** Full-screen page for a module that is built in a later phase. Back button works. */
@Composable
fun ComingSoonScreen(
    title: String,
    message: String,
    onBack: () -> Unit,
    icon: ImageVector = Icons.Filled.Construction
) {
    CyberBackground {
        Column(modifier = Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(title.uppercase(), style = MaterialTheme.typography.titleMedium)
            }
            PlaceholderContent(
                icon = icon,
                title = "COMING IN PHASE 6",
                message = message
            )
        }
    }
}
