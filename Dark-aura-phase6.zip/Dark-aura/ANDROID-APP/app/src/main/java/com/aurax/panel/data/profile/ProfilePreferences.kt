package com.aurax.panel.data.profile

import android.content.Context

/** Local display name (stored on this device only). */
class ProfilePreferences(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aurax_prefs", Context.MODE_PRIVATE)

    fun getName(): String =
        prefs.getString(KEY_NAME, null)?.takeIf { it.isNotBlank() } ?: DEFAULT_NAME

    fun setName(name: String) {
        prefs.edit().putString(KEY_NAME, name).apply()
    }

    companion object {
        private const val KEY_NAME = "display_name"
        const val DEFAULT_NAME = "Player"
        const val MIN_NAME = 2
        const val MAX_NAME = 20
        fun sanitize(raw: String): String = raw.trim().take(MAX_NAME)
    }
}
