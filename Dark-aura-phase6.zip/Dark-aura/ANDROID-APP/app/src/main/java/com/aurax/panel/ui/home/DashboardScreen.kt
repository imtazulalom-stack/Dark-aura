package com.aurax.panel.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurax.panel.BuildConfig
import com.aurax.panel.data.license.LicenseDisplay
import com.aurax.panel.ui.components.AuraLogo
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.StatusChip
import com.aurax.panel.ui.features.FeatureModule
import com.aurax.panel.ui.features.ModuleCard
import com.aurax.panel.ui.main.MainUiState
import com.aurax.panel.ui.theme.AuraSurfaceHigh
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusError
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.StatusWarning
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary
import java.util.Locale

@Composable
fun DashboardScreen(
    state: MainUiState,
    onOpenModule: (FeatureModule) -> Unit,
    onOpenSettings: () -> Unit,
    onChangeGame: () -> Unit
) {
    var showNotifications by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(8.dp))

        // Top bar: branding, notifications, settings
        Row(verticalAlignment = Alignment.CenterVertically) {
            AuraLogo(logoSize = 40.dp)
            Spacer(Modifier.width(12.dp))
            Text(
                "AURA X",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    brush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))
                )
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showNotifications = true }) {
                Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
        }

        Spacer(Modifier.height(16.dp))

        // User profile
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NeonBlue, NeonPurple))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = state.playerName.take(1).uppercase(),
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("WELCOME", style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp), color = TextMuted)
                    Text(state.playerName, style = MaterialTheme.typography.titleMedium.copy(fontSize = 20.sp))
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Activation status + remaining time
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "ACTIVATION",
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp, letterSpacing = 1.5.sp),
                    color = TextMuted
                )
                Spacer(Modifier.weight(1f))
                when (state.license) {
                    LicenseDisplay.NotVerified -> StatusChip("DEV MODE", StatusWarning)
                    is LicenseDisplay.Active -> StatusChip("ACTIVE", StatusSuccess)
                    LicenseDisplay.Expired -> StatusChip("EXPIRED", StatusError)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = when (val l = state.license) {
                    LicenseDisplay.NotVerified -> "--:--:--"
                    is LicenseDisplay.Active -> formatRemaining(l.remainingSeconds)
                    LicenseDisplay.Expired -> "00:00:00"
                },
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 34.sp,
                    brush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))
                )
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = when (state.license) {
                    LicenseDisplay.NotVerified ->
                        "License is not verified: this is a debug build. The real status and countdown arrive with the server check in Phase 7."
                    is LicenseDisplay.Active -> "Time remaining on your license"
                    LicenseDisplay.Expired -> "Your license has expired. Enter a new key."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
        }

        Spacer(Modifier.height(14.dp))

        // Selected game
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "GAME VERSION",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp, letterSpacing = 1.5.sp),
                        color = TextMuted
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        state.game?.title ?: "Not selected",
                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                        color = NeonBlue
                    )
                }
                TextButton(onClick = onChangeGame) {
                    Text("CHANGE", color = NeonPurple, style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        Text(
            "QUICK ACCESS",
            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp),
            color = TextMuted
        )
        Spacer(Modifier.height(12.dp))

        FeatureModule.entries.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                pair.forEach { module ->
                    ModuleCard(
                        module = module,
                        onClick = { onOpenModule(module) },
                        compact = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
        }

        Spacer(Modifier.height(8.dp))
        Text(
            text = "AURA X v${BuildConfig.VERSION_NAME}",
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(24.dp))
    }

    if (showNotifications) {
        AlertDialog(
            onDismissRequest = { showNotifications = false },
            confirmButton = {
                TextButton(onClick = { showNotifications = false }) {
                    Text("CLOSE", color = NeonBlue)
                }
            },
            title = { Text("Notifications") },
            text = {
                Text("No notifications yet. Announcements from the AURA X admin will appear here once the server is connected.")
            },
            containerColor = AuraSurfaceHigh,
            titleContentColor = TextPrimary,
            textContentColor = TextMuted
        )
    }
}

private fun formatRemaining(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0)
    val days = s / 86_400
    val h = (s % 86_400) / 3_600
    val m = (s % 3_600) / 60
    val sec = s % 60
    val clock = String.format(Locale.US, "%02d:%02d:%02d", h, m, sec)
    return if (days > 0) "${days}d $clock" else clock
}
