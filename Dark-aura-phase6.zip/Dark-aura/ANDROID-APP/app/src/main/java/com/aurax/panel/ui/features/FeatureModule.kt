package com.aurax.panel.ui.features

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.graphics.vector.ImageVector

/** The practice modules (built in Phase 6). */
enum class FeatureModule(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector
) {
    SENSITIVITY("sensitivity", "Sensitivity Guide", "Profiles, DPI info and custom values", Icons.Filled.Tune),
    AIM("aim", "Aim Practice", "Offline target practice simulator", Icons.Filled.GpsFixed),
    HEADSHOT("headshot", "Headshot Practice", "Head-zone practice simulator", Icons.Filled.CenterFocusStrong),
    REACTION("reaction", "Reaction Test", "Measure your reaction in milliseconds", Icons.Filled.Bolt),
    LEADERBOARD("leaderboard", "Leaderboard", "Top practice scores and reaction times", Icons.Filled.EmojiEvents),
    CUSTOM_UI("custom_ui", "Custom Interface", "Colors, layout, sound and vibration", Icons.Filled.Palette);

    companion object {
        fun fromId(id: String?): FeatureModule? = entries.firstOrNull { it.id == id }
    }
}
