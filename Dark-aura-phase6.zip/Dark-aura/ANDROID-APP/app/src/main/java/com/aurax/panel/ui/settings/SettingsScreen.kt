package com.aurax.panel.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurax.panel.BuildConfig
import com.aurax.panel.data.practice.PracticeStore
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.practice.PracticeScaffold
import com.aurax.panel.ui.practice.SectionTitle
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

private const val PRIVACY = "AURA X stores your display name, chosen game version, practice scores and settings only on this phone. " +
    "Practice runs never leave the device. When license activation is connected (Phase 7), the activation key and an anonymous " +
    "device ID are sent to the AURA X server to check validity and expiry. AURA X does not read or change any game, does not collect " +
    "contacts, messages or location, and has no ads."

private const val TERMS = "AURA X is an offline practice and training tool. It does not connect to, read, modify or automate any game, " +
    "and provides no auto-aim, auto-fire, enemy tracking or anti-cheat bypass. Activation keys are single-use and expire by server time. " +
    "Keys can be revoked by the administrator. Using AURA X is at your own responsibility."

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { PracticeStore(context) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var cleared by remember { mutableStateOf(false) }

    PracticeScaffold(title = "Settings", onBack = onBack) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            SectionTitle("Practice data")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("Delete all practice history (statistics and leaderboard) from this phone.",
                    style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                Spacer(Modifier.height(12.dp))
                NeonButton(text = "CLEAR HISTORY", onClick = { dialog = "clear" })
                if (cleared) Text("History cleared", color = StatusSuccess, modifier = Modifier.padding(top = 8.dp))
            }

            SectionTitle("About")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Version", color = TextMuted)
                    Text(BuildConfig.VERSION_NAME, color = TextPrimary)
                }
                Spacer(Modifier.height(8.dp))
                Text("AURA X is an offline aim and reaction trainer. It never touches your game.",
                    style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }

            SectionTitle("Legal")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                NeonButton(text = "PRIVACY POLICY", onClick = { dialog = "privacy" })
                Spacer(Modifier.height(10.dp))
                NeonButton(text = "TERMS OF USE", onClick = { dialog = "terms" })
            }

            SectionTitle("Account")
            Text("Log out and license controls arrive with the server check in Phase 7.",
                style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            Spacer(Modifier.height(24.dp))
        }
    }

    when (dialog) {
        "clear" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Clear history?") },
            text = { Text("This permanently deletes your practice runs from this phone.") },
            confirmButton = { TextButton(onClick = { store.clear(); cleared = true; dialog = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        "privacy" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Privacy policy") },
            text = { Text(PRIVACY) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close") } }
        )
        "terms" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Terms of use") },
            text = { Text(TERMS) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Close") } }
        )
    }
}
