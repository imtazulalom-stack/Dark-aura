package com.aurax.panel.ui.customui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurax.panel.data.settings.AppSettings
import com.aurax.panel.data.settings.TARGET_COLORS
import com.aurax.panel.data.settings.TARGET_SIZES
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.practice.PracticeScaffold
import com.aurax.panel.ui.practice.SectionTitle
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

/** Target color/size, vibration and sound for the practice modules. Saved on this phone. */
@Composable
fun CustomInterfaceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    var vib by remember { mutableStateOf(settings.vibration) }
    var snd by remember { mutableStateOf(settings.sound) }
    var size by remember { mutableIntStateOf(settings.targetSize) }
    var color by remember { mutableIntStateOf(settings.targetColor) }

    PracticeScaffold(title = "Custom Interface", onBack = onBack) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            SectionTitle("Preview")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.fillMaxWidth().height(110.dp), contentAlignment = Alignment.Center) {
                    val c = TARGET_COLORS[color].second
                    val r = when (size) { 0 -> 26f; 2 -> 46f; else -> 36f }
                    Canvas(Modifier.size(100.dp)) {
                        val center = Offset(this.size.width / 2f, this.size.height / 2f)
                        val s = r * density / 2f * 1.4f
                        drawCircle(c.copy(alpha = 0.35f), s, center)
                        drawCircle(c, s, center, style = Stroke(3.dp.toPx()))
                        drawCircle(c, s * 0.6f, center, style = Stroke(3.dp.toPx()))
                    }
                }
            }

            SectionTitle("Target color")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TARGET_COLORS.forEachIndexed { i, (name, _) ->
                    FilterChip(selected = color == i, onClick = { color = i; settings.targetColor = i }, label = { Text(name) })
                }
            }

            SectionTitle("Target size")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TARGET_SIZES.forEachIndexed { i, name ->
                    FilterChip(selected = size == i, onClick = { size = i; settings.targetSize = i }, label = { Text(name) })
                }
            }

            SectionTitle("Feedback")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Vibration on hit", color = TextPrimary)
                    Switch(checked = vib, onCheckedChange = { vib = it; settings.vibration = it })
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Sound on hit", color = TextPrimary)
                    Switch(checked = snd, onCheckedChange = { snd = it; settings.sound = it })
                }
            }
            Text(
                "Changes are saved automatically and apply to Aim Practice and Headshot Practice.",
                style = MaterialTheme.typography.bodyMedium, color = TextMuted,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }
}
