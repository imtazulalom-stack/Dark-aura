package com.aurax.panel.ui.leaderboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurax.panel.data.practice.PracticeStore
import com.aurax.panel.data.practice.PracticeType
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.practice.PracticeScaffold
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Personal bests stored on this phone. There is no online ranking. */
@Composable
fun LeaderboardScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val sessions = remember { PracticeStore(context).all() }
    var selected by remember { mutableStateOf(PracticeType.AIM) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    val rows = sessions.filter { it.type == selected }.let { list ->
        if (selected == PracticeType.REACTION) list.filter { it.reactionMs >= 0 }.sortedBy { it.reactionMs }
        else list.sortedByDescending { it.score }
    }.take(10)

    PracticeScaffold(title = "Leaderboard", onBack = onBack) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(
                "Your personal best runs. Stored on this phone only; online ranking is not available.",
                style = MaterialTheme.typography.bodyMedium, color = TextMuted
            )
            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PracticeType.entries.forEach { t ->
                    FilterChip(
                        selected = selected == t,
                        onClick = { selected = t },
                        label = { Text(t.label.substringBefore(" ")) }
                    )
                }
            }
            if (rows.isEmpty()) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("No runs yet. Play ${selected.label} to set your first record.", color = TextMuted)
                }
            } else {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    rows.forEachIndexed { i, s ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("#${i + 1}", color = if (i == 0) NeonPurple else TextMuted)
                            Text(
                                if (selected == PracticeType.REACTION) "${s.reactionMs} ms" else "${s.score} pts",
                                color = NeonBlue, style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (selected == PracticeType.REACTION) fmt.format(Date(s.timeMs))
                                else "${s.accuracy}%  ${fmt.format(Date(s.timeMs))}",
                                color = TextPrimary, style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}
