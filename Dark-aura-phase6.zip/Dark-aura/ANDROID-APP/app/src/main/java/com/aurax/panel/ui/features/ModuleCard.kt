package com.aurax.panel.ui.features

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

/** compact = small tile (dashboard grid). Otherwise a full-width row (Features tab). */
@Composable
fun ModuleCard(
    module: FeatureModule,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "moduleScale"
    )
    val shape = RoundedCornerShape(20.dp)
    val container = modifier
        .then(if (compact) Modifier.height(132.dp) else Modifier)
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f))
            )
        )
        .border(
            1.dp,
            Brush.linearGradient(listOf(NeonBlue.copy(alpha = 0.45f), NeonPurple.copy(alpha = 0.3f))),
            shape
        )
        .clickable(interactionSource = interaction, indication = null, onClick = onClick)
        .padding(14.dp)

    if (compact) {
        Column(modifier = container) {
            IconBadge(module)
            Spacer(Modifier.height(10.dp))
            Text(module.title, style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp), color = TextPrimary)
            Spacer(Modifier.height(2.dp))
            Text(
                module.description,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, lineHeight = 16.sp),
                color = TextMuted,
                maxLines = 2
            )
        }
    } else {
        Row(modifier = container, verticalAlignment = Alignment.CenterVertically) {
            IconBadge(module)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(module.title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                Spacer(Modifier.height(2.dp))
                Text(module.description, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = TextMuted
            )
        }
    }
}

@Composable
private fun IconBadge(module: FeatureModule) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.linearGradient(
                    listOf(NeonBlue.copy(alpha = 0.25f), NeonPurple.copy(alpha = 0.25f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(module.icon, contentDescription = null, tint = NeonBlue, modifier = Modifier.size(24.dp))
    }
}
