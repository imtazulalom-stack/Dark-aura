package com.aurax.panel.data.game

/**
 * The three supported game versions.
 * [id] is the key used to store a separate settings/sensitivity profile per game (Phase 6).
 */
enum class GameVersion(val id: String, val title: String, val subtitle: String) {
    GLOBAL("global", "Free Fire Global", "International version"),
    INDIA("india", "Free Fire India", "India edition"),
    MAX("max", "Free Fire MAX", "Enhanced graphics edition");

    companion object {
        fun fromId(id: String?): GameVersion? = entries.firstOrNull { it.id == id }
    }
}
