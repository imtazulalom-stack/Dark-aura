package com.aurax.panel.ui.games

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.aurax.panel.data.game.GamePreferences
import com.aurax.panel.data.game.GameVersion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GameSelectionViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = GamePreferences(app)

    private val _selected = MutableStateFlow(prefs.getSelected())
    val selected: StateFlow<GameVersion?> = _selected.asStateFlow()

    fun select(game: GameVersion) {
        _selected.value = game
    }

    /** Saves the choice. Returns false if nothing is selected. */
    fun confirm(): Boolean {
        val game = _selected.value ?: return false
        prefs.setSelected(game)
        return true
    }
}
