package com.aurax.panel

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.aurax.panel.navigation.AuraNavHost
import com.aurax.panel.ui.theme.AuraXTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AuraXTheme {
                AuraNavHost()
            }
        }
    }
}
