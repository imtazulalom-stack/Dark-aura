package com.aurax.panel.navigation

object Routes {
    const val SPLASH = "splash"
    const val ACTIVATION = "activation"
    const val GAME_SELECTION = "game_selection"
    const val MAIN = "main"
    const val SETTINGS = "settings"
    const val MODULE_PATTERN = "module/{id}"

    fun module(id: String) = "module/$id"
}
