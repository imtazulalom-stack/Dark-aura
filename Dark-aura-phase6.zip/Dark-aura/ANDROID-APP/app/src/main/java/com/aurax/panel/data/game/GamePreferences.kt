package com.aurax.panel.data.game

import android.content.Context

/** Remembers the chosen game version on this device. */
class GamePreferences(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aurax_prefs", Context.MODE_PRIVATE)

    fun getSelected(): GameVersion? = GameVersion.fromId(prefs.getString(KEY_GAME, null))

    fun setSelected(game: GameVersion) {
        prefs.edit().putString(KEY_GAME, game.id).apply()
    }

    private companion object {
        const val KEY_GAME = "selected_game"
    }
}
