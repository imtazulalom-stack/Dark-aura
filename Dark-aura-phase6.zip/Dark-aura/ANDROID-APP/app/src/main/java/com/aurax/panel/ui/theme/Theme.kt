package com.aurax.panel.ui.theme

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider

private val AuraColorScheme = darkColorScheme(
    primary = NeonBlue,
    onPrimary = AuraBlack,
    secondary = NeonPurple,
    onSecondary = TextPrimary,
    tertiary = ElectricBlue,
    background = AuraBlack,
    onBackground = TextPrimary,
    surface = AuraSurface,
    onSurface = TextPrimary,
    surfaceVariant = AuraSurfaceHigh,
    onSurfaceVariant = TextMuted,
    error = StatusError
)

@Composable
fun AuraXTheme(content: @Composable () -> Unit) {
    // AURA X is always dark. Dynamic (wallpaper) colors are intentionally not used.
    MaterialTheme(
        colorScheme = AuraColorScheme,
        typography = AuraTypography
    ) {
        // Without a Surface, Text defaults to black. Make light text the default everywhere.
        CompositionLocalProvider(LocalContentColor provides TextPrimary, content = content)
    }
}
