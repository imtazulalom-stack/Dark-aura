package com.aurax.panel.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aurax.panel.BuildConfig
import com.aurax.panel.ui.activation.ActivationScreen
import com.aurax.panel.ui.features.FeatureModule
import com.aurax.panel.ui.games.GameSelectionScreen
import com.aurax.panel.ui.customui.CustomInterfaceScreen
import com.aurax.panel.ui.leaderboard.LeaderboardScreen
import com.aurax.panel.ui.main.MainScreen
import com.aurax.panel.ui.practice.AimMode
import com.aurax.panel.ui.practice.AimPracticeScreen
import com.aurax.panel.ui.practice.ReactionTestScreen
import com.aurax.panel.ui.sensitivity.SensitivityGuideScreen
import com.aurax.panel.ui.settings.SettingsScreen
import com.aurax.panel.ui.splash.SplashScreen

@Composable
fun AuraNavHost() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(600)) },
        exitTransition = { fadeOut(tween(600)) },
        popEnterTransition = { fadeIn(tween(600)) },
        popExitTransition = { fadeOut(tween(600)) }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    nav.navigate(Routes.ACTIVATION) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.ACTIVATION) {
            ActivationScreen(
                onActivated = { nav.goToGameSelectionAfterActivation() },
                // Debug builds only. In a release APK BuildConfig.DEBUG is false, so this is null.
                onDebugSkip = if (BuildConfig.DEBUG) {
                    { nav.goToGameSelectionAfterActivation() }
                } else null
            )
        }

        composable(Routes.GAME_SELECTION) {
            GameSelectionScreen(
                onContinue = {
                    // Came from the main screen ("Change game")? Just go back to it.
                    val cameFromMain = nav.popBackStack(Routes.MAIN, inclusive = false)
                    if (!cameFromMain) {
                        nav.navigate(Routes.MAIN) {
                            popUpTo(Routes.GAME_SELECTION) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Routes.MAIN) {
            MainScreen(
                onOpenModule = { nav.navigate(Routes.module(it.id)) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                onChangeGame = { nav.navigate(Routes.GAME_SELECTION) }
            )
        }

        composable(
            route = Routes.MODULE_PATTERN,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val back: () -> Unit = { nav.popBackStack() }
            when (FeatureModule.fromId(entry.arguments?.getString("id"))) {
                FeatureModule.AIM -> AimPracticeScreen(AimMode.TARGETS, back)
                FeatureModule.HEADSHOT -> AimPracticeScreen(AimMode.HEADSHOT, back)
                FeatureModule.REACTION -> ReactionTestScreen(back)
                FeatureModule.SENSITIVITY -> SensitivityGuideScreen(back)
                FeatureModule.LEADERBOARD -> LeaderboardScreen(back)
                FeatureModule.CUSTOM_UI -> CustomInterfaceScreen(back)
                null -> LaunchedEffect(Unit) { back() }
            }
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { nav.popBackStack() })
        }
    }
}

private fun NavHostController.goToGameSelectionAfterActivation() {
    navigate(Routes.GAME_SELECTION) {
        popUpTo(Routes.ACTIVATION) { inclusive = true }
    }
}
