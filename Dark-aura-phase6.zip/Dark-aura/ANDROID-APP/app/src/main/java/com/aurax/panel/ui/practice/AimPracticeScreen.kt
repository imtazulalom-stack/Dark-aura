package com.aurax.panel.ui.practice

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.aurax.panel.data.practice.PracticeStore
import com.aurax.panel.data.practice.PracticeType
import com.aurax.panel.data.practice.Session
import com.aurax.panel.data.settings.AppSettings
import com.aurax.panel.data.settings.TARGET_COLORS
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.StatusWarning
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.util.Feedback
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

enum class AimMode { TARGETS, HEADSHOT }

private enum class Phase { READY, RUNNING, DONE }

private class Target(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val spawnMs: Long,
    val lifeMs: Long
)

private const val DURATION_MS = 30_000L
private const val MAX_TARGETS = 3

/**
 * Offline practice simulator. Runs entirely inside this app. It does not connect to,
 * read, or change any game.
 *
 * TARGETS: tap moving round targets.
 * HEADSHOT: tap moving figures; the head zone counts as a headshot.
 */
@Composable
fun AimPracticeScreen(mode: AimMode, onBack: () -> Unit) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val settings = remember { AppSettings(context) }
    val store = remember { PracticeStore(context) }
    val feedback = remember { Feedback(context, settings) }
    DisposableEffect(Unit) { onDispose { feedback.release() } }

    val type = if (mode == AimMode.HEADSHOT) PracticeType.HEADSHOT else PracticeType.AIM
    val sizeFactor = when (settings.targetSize) {
        0 -> 0.8f
        2 -> 1.25f
        else -> 1f
    }
    val baseRadius = with(density) { 30.dp.toPx() } * sizeFactor
    val speedBase = with(density) { 90.dp.toPx() }
    val accent: Color = TARGET_COLORS[settings.targetColor].second

    var phase by remember { mutableStateOf(Phase.READY) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    val targets = remember { ArrayList<Target>() }
    var tick by remember { mutableIntStateOf(0) }
    var timeLeftMs by remember { mutableLongStateOf(DURATION_MS) }
    var nowMs by remember { mutableLongStateOf(0L) }
    var hits by remember { mutableIntStateOf(0) }
    var headHits by remember { mutableIntStateOf(0) }
    var misses by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var reactionSum by remember { mutableLongStateOf(0L) }
    var result by remember { mutableStateOf<Session?>(null) }
    var newBest by remember { mutableStateOf(false) }

    fun startGame() {
        targets.clear()
        hits = 0
        headHits = 0
        misses = 0
        score = 0
        reactionSum = 0L
        nowMs = 0L
        timeLeftMs = DURATION_MS
        result = null
        newBest = false
        phase = Phase.RUNNING
    }

    LaunchedEffect(phase) {
        if (phase != Phase.RUNNING) return@LaunchedEffect
        val rnd = Random(System.nanoTime())
        val start = withFrameNanosCompat()
        var last = start
        var nextSpawn = 0L
        while (true) {
            val now = withFrameNanosCompat()
            val dt = (now - last) / 1_000_000_000f
            last = now
            val elapsed = (now - start) / 1_000_000L
            nowMs = elapsed
            if (elapsed >= DURATION_MS) break
            timeLeftMs = DURATION_MS - elapsed

            val w = area.width.toFloat()
            val h = area.height.toFloat()
            val margin = baseRadius * 2.6f
            if (w > margin * 2f && h > margin * 2f) {
                if (elapsed >= nextSpawn && targets.size < MAX_TARGETS) {
                    val ang = rnd.nextFloat() * 6.2831855f
                    val sp = speedBase * (0.6f + rnd.nextFloat())
                    targets.add(
                        Target(
                            x = margin + rnd.nextFloat() * (w - 2f * margin),
                            y = margin + rnd.nextFloat() * (h - 2f * margin),
                            vx = cos(ang) * sp,
                            vy = sin(ang) * sp,
                            spawnMs = elapsed,
                            lifeMs = 1600L
                        )
                    )
                    nextSpawn = elapsed + 500L
                }
                val iter = targets.iterator()
                while (iter.hasNext()) {
                    val t = iter.next()
                    t.x += t.vx * dt
                    t.y += t.vy * dt
                    val side = baseRadius * 1.2f
                    val top = if (mode == AimMode.HEADSHOT) baseRadius * 2.4f else side
                    if (t.x < side) { t.x = side; t.vx = abs(t.vx) }
                    else if (t.x > w - side) { t.x = w - side; t.vx = -abs(t.vx) }
                    if (t.y < top) { t.y = top; t.vy = abs(t.vy) }
                    else if (t.y > h - side) { t.y = h - side; t.vy = -abs(t.vy) }
                    if (elapsed - t.spawnMs >= t.lifeMs) {
                        iter.remove()
                        misses++ // target ran away
                    }
                }
            }
            tick++
        }
        targets.clear()
        val shots = hits + misses
        val acc = if (shots > 0) hits * 100 / shots else 0
        val headAcc = if (mode == AimMode.HEADSHOT && shots > 0) headHits * 100 / shots else -1
        val avg = if (hits > 0) (reactionSum / hits).toInt() else -1
        val prevBest = store.all().filter { it.type == type }.maxOfOrNull { it.score } ?: 0
        val session = Session(type, System.currentTimeMillis(), score, acc, headAcc, avg)
        store.add(session)
        newBest = score > prevBest && score > 0
        result = session
        phase = Phase.DONE
    }

    fun register(index: Int, head: Boolean) {
        val t = targets[index]
        val reaction = max(0L, nowMs - t.spawnMs)
        val speedBonus = max(0L, 1000L - reaction).toInt() / 10
        val base = when {
            mode == AimMode.TARGETS -> 100
            head -> 150
            else -> 40
        }
        score += base + speedBonus
        hits++
        if (head) headHits++
        reactionSum += reaction
        targets.removeAt(index)
        feedback.hit()
    }

    fun onTapAt(p: Offset) {
        if (phase != Phase.RUNNING) return
        for (i in targets.indices.reversed()) {
            val t = targets[i]
            if (mode == AimMode.HEADSHOT) {
                val headR = baseRadius * 0.62f
                val headCy = t.y - baseRadius * 1.55f
                if (hypot(p.x - t.x, p.y - headCy) <= headR * 1.15f) {
                    register(i, head = true)
                    return
                }
                if (hypot(p.x - t.x, p.y - t.y) <= baseRadius * 1.1f) {
                    register(i, head = false)
                    return
                }
            } else if (hypot(p.x - t.x, p.y - t.y) <= baseRadius * 1.1f) {
                register(i, head = false)
                return
            }
        }
        misses++
        score = max(0, score - 25)
        feedback.miss()
    }

    val title = if (mode == AimMode.HEADSHOT) "Headshot Practice" else "Aim Practice"
    val liveAcc = if (hits + misses > 0) hits * 100 / (hits + misses) else 0

    PracticeScaffold(title = title, onBack = onBack) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            StatTile("TIME", "${(timeLeftMs + 999L) / 1000L}s", Modifier.weight(1f))
            StatTile("SCORE", "$score", Modifier.weight(1f), NeonPurple)
            StatTile("ACCURACY", "$liveAcc%", Modifier.weight(1f), StatusSuccess)
        }

        val boxShape = RoundedCornerShape(20.dp)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
                .clip(boxShape)
                .background(Color.Black.copy(alpha = 0.35f))
                .border(1.dp, NeonBlue.copy(alpha = 0.4f), boxShape)
                .onSizeChanged { area = it }
                .pointerInput(Unit) {
                    detectTapGestures { offset -> onTapAt(offset) }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE")
                val redraw = tick // reading this state redraws every frame
                val stroke = Stroke(width = 3.dp.toPx())
                targets.toList().forEach { t ->
                    val life = 1f - ((nowMs - t.spawnMs).toFloat() / t.lifeMs).coerceIn(0f, 1f)
                    val a = 0.35f + 0.65f * life
                    val c = Offset(t.x, t.y)
                    if (mode == AimMode.HEADSHOT) {
                        drawCircle(NeonPurple.copy(alpha = a * 0.5f), baseRadius, c)
                        drawCircle(NeonPurple.copy(alpha = a), baseRadius, c, style = stroke)
                        val hc = Offset(t.x, t.y - baseRadius * 1.55f)
                        val hr = baseRadius * 0.62f
                        drawCircle(accent.copy(alpha = a * 0.6f), hr, hc)
                        drawCircle(accent.copy(alpha = a), hr, hc, style = stroke)
                        drawCircle(Color.White.copy(alpha = a), hr * 0.22f, hc)
                    } else {
                        drawCircle(accent.copy(alpha = a * 0.35f), baseRadius, c)
                        drawCircle(accent.copy(alpha = a), baseRadius, c, style = stroke)
                        drawCircle(accent.copy(alpha = a), baseRadius * 0.6f, c, style = stroke)
                        drawCircle(Color.White.copy(alpha = a), baseRadius * 0.2f, c)
                    }
                }
            }

            if (phase == Phase.READY) {
                GlassCard(modifier = Modifier.padding(24.dp)) {
                    Text(title.uppercase(), style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (mode == AimMode.HEADSHOT)
                            "Tap the HEAD circle of each moving figure for a headshot (150 pts). Body hits give 40 pts. Misses cost 25 pts. 30 seconds."
                        else
                            "Tap each moving target before it disappears. Faster hits score more. Misses cost 25 pts. 30 seconds.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Offline practice only. This does not touch your game.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    NeonButton(text = "START", onClick = { startGame() })
                }
            }

            val done = result
            if (phase == Phase.DONE && done != null) {
                GlassCard(modifier = Modifier.padding(24.dp)) {
                    Text("TIME UP", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                    if (newBest) {
                        Text("NEW BEST SCORE", color = StatusWarning,
                            style = MaterialTheme.typography.labelLarge, modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatTile("SCORE", "${done.score}", Modifier.weight(1f), NeonPurple)
                        StatTile("ACCURACY", "${done.accuracy}%", Modifier.weight(1f), StatusSuccess)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        StatTile(
                            "AVG REACTION",
                            if (done.reactionMs >= 0) "${done.reactionMs} ms" else "--",
                            Modifier.weight(1f)
                        )
                        if (done.headshotAcc >= 0) {
                            StatTile("HEADSHOT ACC", "${done.headshotAcc}%", Modifier.weight(1f), accent)
                        } else {
                            StatTile("HITS / MISSES", "$hits / $misses", Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    NeonButton(text = "PLAY AGAIN", onClick = { startGame() })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

private suspend fun withFrameNanosCompat(): Long =
    androidx.compose.runtime.withFrameNanos { it }
