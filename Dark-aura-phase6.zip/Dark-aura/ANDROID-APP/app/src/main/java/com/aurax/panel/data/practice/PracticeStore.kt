package com.aurax.panel.data.practice

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class PracticeType(val id: String, val label: String) {
    AIM("aim", "Aim Practice"),
    HEADSHOT("head", "Headshot Practice"),
    REACTION("reaction", "Reaction Test");

    companion object {
        fun fromId(id: String): PracticeType? = entries.firstOrNull { it.id == id }
    }
}

/** One finished practice run. accuracy / headshotAcc / reactionMs are -1 when not applicable. */
data class Session(
    val type: PracticeType,
    val timeMs: Long,
    val score: Int,
    val accuracy: Int,
    val headshotAcc: Int,
    val reactionMs: Int
)

/** Practice history, stored only on this phone (SharedPreferences, last 300 runs). */
class PracticeStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("aurax_practice", Context.MODE_PRIVATE)

    fun all(): List<Session> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Session>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val type = PracticeType.fromId(o.optString("t")) ?: continue
                out.add(
                    Session(
                        type = type,
                        timeMs = o.optLong("ts"),
                        score = o.optInt("s"),
                        accuracy = o.optInt("a", -1),
                        headshotAcc = o.optInt("h", -1),
                        reactionMs = o.optInt("r", -1)
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(session: Session) {
        val list = (all() + session).takeLast(MAX)
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("t", s.type.id)
                    .put("ts", s.timeMs)
                    .put("s", s.score)
                    .put("a", s.accuracy)
                    .put("h", s.headshotAcc)
                    .put("r", s.reactionMs)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    companion object {
        private const val KEY = "sessions"
        const val MAX = 300
    }
}
