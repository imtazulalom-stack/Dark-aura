package com.aurax.panel.ui.sensitivity

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurax.panel.data.settings.AppSettings
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.practice.PracticeScaffold
import com.aurax.panel.ui.practice.SectionTitle
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

private val FIELDS = listOf(
    "general" to "General",
    "reddot" to "Red Dot",
    "scope2" to "2x Scope",
    "scope4" to "4x Scope",
    "awm" to "AWM Scope",
    "freelook" to "Free Look"
)

private data class Profile(val name: String, val note: String, val values: Map<String, Int>)

// Generic starting points only. They are NOT official values and every phone/hand is different.
private val PROFILES = listOf(
    Profile(
        "Steady (beginner)", "Slower and easier to control.",
        mapOf("general" to 65, "reddot" to 55, "scope2" to 50, "scope4" to 45, "awm" to 30, "freelook" to 60)
    ),
    Profile(
        "Balanced", "Good middle ground for most players.",
        mapOf("general" to 80, "reddot" to 70, "scope2" to 62, "scope4" to 55, "awm" to 38, "freelook" to 70)
    ),
    Profile(
        "Fast", "Quick turns. Needs a steady thumb.",
        mapOf("general" to 92, "reddot" to 85, "scope2" to 75, "scope4" to 66, "awm" to 45, "freelook" to 80)
    )
)

@Composable
fun SensitivityGuideScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val metrics = context.resources.displayMetrics
    val values = remember { mutableStateMapOf<String, Int>().apply { FIELDS.forEach { (k, _) -> put(k, settings.getSens(k)) } } }
    var saved by remember { mutableStateOf(false) }

    PracticeScaffold(title = "Sensitivity Guide", onBack = onBack) {
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            SectionTitle("Your phone")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Screen", color = TextMuted)
                    Text("${metrics.widthPixels} x ${metrics.heightPixels} px", color = TextPrimary)
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Density", color = TextMuted)
                    Text("${metrics.densityDpi} dpi", color = TextPrimary)
                }
            }

            SectionTitle("DPI information")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "DPI means dots (pixels) per inch. On a phone it is the screen density, fixed by the manufacturer. " +
                        "Free Fire has no DPI setting: it uses sensitivity sliders from 0 to 100.\n\n" +
                        "Changing the density in Developer options only resizes the interface. It does not give reliable aim " +
                        "improvement and can break layouts, so it is not recommended. Tune the in-game sliders instead.",
                    style = MaterialTheme.typography.bodyMedium, color = TextMuted
                )
            }

            SectionTitle("Starting profiles")
            Text(
                "Generic starting points, not official values. Test them in the game's Training Ground and adjust.",
                style = MaterialTheme.typography.bodyMedium, color = TextMuted
            )
            Spacer(Modifier.height(8.dp))
            PROFILES.forEach { p ->
                GlassCard(modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium, color = NeonBlue)
                    Text(p.note, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    Spacer(Modifier.height(8.dp))
                    FIELDS.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            row.forEach { (k, label) ->
                                Text("$label: ${p.values[k]}", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    NeonButton(text = "USE THIS", onClick = {
                        FIELDS.forEach { (k, _) -> values[k] = p.values[k] ?: 50 }
                        saved = false
                    })
                }
            }

            SectionTitle("My custom values")
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                FIELDS.forEach { (k, label) ->
                    val v = values[k] ?: 50
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = TextPrimary)
                        Text("$v", color = NeonPurple)
                    }
                    Slider(
                        value = v.toFloat(),
                        onValueChange = { values[k] = it.toInt(); saved = false },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonBlue, activeTrackColor = NeonBlue)
                    )
                }
                Spacer(Modifier.height(8.dp))
                NeonButton(text = "SAVE MY VALUES", onClick = {
                    FIELDS.forEach { (k, _) -> settings.setSens(k, values[k] ?: 50) }
                    saved = true
                })
                if (saved) {
                    Text("Saved on this phone", color = StatusSuccess,
                        style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
