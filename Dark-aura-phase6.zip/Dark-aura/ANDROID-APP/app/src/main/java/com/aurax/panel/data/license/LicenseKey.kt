package com.aurax.panel.data.license

/** Key format made by the Admin Website: AURA-XXXX-XXXX-XXXX-XXXX */
object LicenseKey {
    const val PREFIX = "AURA"
    const val BODY_LENGTH = 16
    // Same alphabet as the admin website (no I, O, 0, 1 to avoid confusion)
    private const val ALLOWED = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    /** Turns anything typed or pasted into the 16-character body (no "AURA", no dashes). */
    fun clean(raw: String): String {
        var s = raw.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }
        if (s.length > BODY_LENGTH && s.startsWith(PREFIX)) s = s.removePrefix(PREFIX)
        return s.take(BODY_LENGTH)
    }

    fun isComplete(body: String) = body.length == BODY_LENGTH

    fun hasInvalidChars(body: String) = body.any { it !in ALLOWED }

    fun full(body: String) = PREFIX + "-" + body.chunked(4).joinToString("-")
}
