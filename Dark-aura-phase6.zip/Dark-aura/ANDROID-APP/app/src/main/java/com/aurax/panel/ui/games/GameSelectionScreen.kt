package com.aurax.panel.ui.games

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurax.panel.data.game.GameVersion
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.TextMuted

@Composable
fun GameSelectionScreen(
    onContinue: () -> Unit,
    viewModel: GameSelectionViewModel = viewModel()
) {
    val selected by viewModel.selected.collectAsStateWithLifecycle()
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }

    CyberBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
            Spacer(Modifier.height(36.dp))
            Text(
                text = "SELECT GAME",
                style = MaterialTheme.typography.headlineMedium.copy(
                    brush = Brush.horizontalGradient(listOf(NeonBlue, NeonPurple))
                )
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Choose your Free Fire version. Each version keeps its own settings and sensitivity profile.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
            Spacer(Modifier.height(24.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GameVersion.entries.forEachIndexed { index, game ->
                    AnimatedVisibility(
                        visible = visible,
                        enter = fadeIn(tween(500, delayMillis = index * 120)) +
                            slideInVertically(tween(500, delayMillis = index * 120)) { it / 4 }
                    ) {
                        GameCard(
                            game = game,
                            selected = game == selected,
                            onClick = { viewModel.select(game) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            NeonButton(
                text = "CONTINUE",
                enabled = selected != null,
                onClick = {
                    if (viewModel.confirm()) onContinue()
                }
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
