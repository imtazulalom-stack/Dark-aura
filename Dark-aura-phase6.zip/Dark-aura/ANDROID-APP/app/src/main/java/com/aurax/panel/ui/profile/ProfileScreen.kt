package com.aurax.panel.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurax.panel.BuildConfig
import com.aurax.panel.data.profile.ProfilePreferences
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.components.auraTextFieldColors
import com.aurax.panel.ui.main.MainUiState
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.NeonPurple
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary

@Composable
fun ProfileScreen(
    state: MainUiState,
    onSaveName: (String) -> Boolean,
    onChangeGame: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val focus = LocalFocusManager.current
    var draft by remember(state.playerName) { mutableStateOf(state.playerName) }
    var saved by remember { mutableStateOf(false) }
    val trimmed = draft.trim()
    val tooShort = trimmed.isNotEmpty() && trimmed.length < ProfilePreferences.MIN_NAME
    val canSave = trimmed.length >= ProfilePreferences.MIN_NAME && trimmed != state.playerName

    val save = {
        if (canSave && onSaveName(trimmed)) {
            focus.clearFocus()
            saved = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(NeonBlue, NeonPurple))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                state.playerName.take(1).uppercase(),
                style = MaterialTheme.typography.displayLarge.copy(letterSpacing = 0.sp),
                color = TextPrimary
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(state.playerName, style = MaterialTheme.typography.headlineMedium)
        Text(state.game?.title ?: "No game selected", style = MaterialTheme.typography.bodyMedium, color = NeonBlue)
        Spacer(Modifier.height(24.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("DISPLAY NAME", style = MaterialTheme.typography.titleMedium, color = NeonBlue)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = draft,
                onValueChange = {
                    draft = it.take(ProfilePreferences.MAX_NAME)
                    saved = false
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = tooShort,
                label = { Text("Name") },
                supportingText = {
                    Text(
                        if (tooShort) "At least ${ProfilePreferences.MIN_NAME} characters."
                        else "${ProfilePreferences.MIN_NAME}-${ProfilePreferences.MAX_NAME} characters. Saved on this device only."
                    )
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { save() }),
                shape = RoundedCornerShape(16.dp),
                colors = auraTextFieldColors()
            )
            Spacer(Modifier.height(12.dp))
            NeonButton(text = "SAVE NAME", onClick = { save() }, enabled = canSave)
            if (saved) {
                Spacer(Modifier.height(8.dp))
                Text("Saved", color = StatusSuccess, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("GAME VERSION", style = MaterialTheme.typography.titleMedium, color = NeonBlue)
            Spacer(Modifier.height(6.dp))
            Text(state.game?.title ?: "Not selected", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(12.dp))
            NeonButton(text = "CHANGE GAME", onClick = onChangeGame)
        }

        Spacer(Modifier.height(14.dp))
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Text("ABOUT", style = MaterialTheme.typography.titleMedium, color = NeonBlue)
            Spacer(Modifier.height(6.dp))
            Row { Text("Version  ", color = TextMuted); Text(BuildConfig.VERSION_NAME) }
            Row { Text("Package  ", color = TextMuted); Text("com.aurax.panel") }
            Spacer(Modifier.height(12.dp))
            NeonButton(text = "OPEN SETTINGS", onClick = onOpenSettings)
        }
        Spacer(Modifier.height(24.dp))
    }
}
