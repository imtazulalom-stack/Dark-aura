package com.aurax.panel.data.license

/**
 * What the dashboard shows about the license.
 * Phase 5: the server check does not exist yet, so the app only ever reports [NotVerified].
 * Phase 7 will produce [Active] and [Expired] from the real, server-verified license.
 */
sealed interface LicenseDisplay {
    data object NotVerified : LicenseDisplay
    data class Active(val remainingSeconds: Long) : LicenseDisplay
    data object Expired : LicenseDisplay
}
