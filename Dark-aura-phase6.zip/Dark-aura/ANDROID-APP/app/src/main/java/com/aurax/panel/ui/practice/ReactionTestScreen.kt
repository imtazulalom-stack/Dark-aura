package com.aurax.panel.ui.practice

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurax.panel.data.practice.PracticeStore
import com.aurax.panel.data.practice.PracticeType
import com.aurax.panel.data.practice.Session
import com.aurax.panel.ui.theme.AuraSurfaceHigh
import com.aurax.panel.ui.theme.StatusError
import com.aurax.panel.ui.theme.StatusSuccess
import com.aurax.panel.ui.theme.StatusWarning
import com.aurax.panel.ui.theme.TextMuted
import com.aurax.panel.ui.theme.TextPrimary
import kotlinx.coroutines.delay
import kotlin.random.Random

private enum class RState { IDLE, WAIT, GO, RESULT, EARLY, FINISHED }

private const val ROUNDS = 5

@Composable
fun ReactionTestScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { PracticeStore(context) }
    var state by remember { mutableStateOf(RState.IDLE) }
    var round by remember { mutableIntStateOf(0) }
    val times = remember { mutableStateListOf<Int>() }
    var goAt by remember { mutableLongStateOf(0L) }
    var lastMs by remember { mutableIntStateOf(0) }

    // Wait a random 1.5-4 s, then turn green. Cancelled automatically if the state changes (early tap).
    LaunchedEffect(state) {
        if (state == RState.WAIT) {
            delay(Random.nextLong(1500L, 4000L))
            goAt = SystemClock.elapsedRealtime()
            state = RState.GO
        }
    }

    fun onTap() {
        when (state) {
            RState.IDLE -> {
                times.clear()
                round = 0
                state = RState.WAIT
            }
            RState.WAIT -> state = RState.EARLY
            RState.GO -> {
                val ms = (SystemClock.elapsedRealtime() - goAt).toInt()
                lastMs = ms
                times.add(ms)
                round++
                if (round >= ROUNDS) {
                    val avg = times.sum() / times.size
                    store.add(
                        Session(PracticeType.REACTION, System.currentTimeMillis(), maxOf(0, 1000 - avg), -1, -1, avg)
                    )
                    state = RState.FINISHED
                } else {
                    state = RState.RESULT
                }
            }
            RState.RESULT, RState.EARLY -> state = RState.WAIT
            RState.FINISHED -> state = RState.IDLE
        }
    }

    val bg: Color = when (state) {
        RState.WAIT -> StatusError.copy(alpha = 0.75f)
        RState.GO -> StatusSuccess.copy(alpha = 0.85f)
        RState.EARLY -> StatusWarning.copy(alpha = 0.8f)
        else -> AuraSurfaceHigh
    }

    fun rating(ms: Int): String = when {
        ms < 200 -> "Excellent"
        ms < 250 -> "Great"
        ms < 300 -> "Good"
        else -> "Keep practicing"
    }

    PracticeScaffold(title = "Reaction Test", onBack = onBack) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(bg)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onTap() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val big = MaterialTheme.typography.headlineMedium.copy(fontSize = 30.sp)
                when (state) {
                    RState.IDLE -> {
                        Text("TAP TO START", style = big, color = TextPrimary, textAlign = TextAlign.Center)
                        Text(
                            "$ROUNDS rounds. When the screen turns GREEN, tap as fast as you can. Tapping early restarts the round.",
                            color = TextMuted, textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                    RState.WAIT -> Text("WAIT FOR GREEN...", style = big, color = Color.White, textAlign = TextAlign.Center)
                    RState.GO -> Text("TAP NOW!", style = big.copy(fontSize = 40.sp), color = Color.Black, textAlign = TextAlign.Center)
                    RState.EARLY -> Text("TOO EARLY!\nTap to try again", style = big, color = Color.Black, textAlign = TextAlign.Center)
                    RState.RESULT -> {
                        Text("$lastMs ms", style = big.copy(fontSize = 44.sp), color = StatusSuccess)
                        Text("Round $round of $ROUNDS. Tap for next.", color = TextMuted,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                    }
                    RState.FINISHED -> {
                        val avg = if (times.isNotEmpty()) times.sum() / times.size else 0
                        val best = times.minOrNull() ?: 0
                        Text("AVERAGE", color = TextMuted, style = MaterialTheme.typography.labelLarge)
                        Text("$avg ms", style = big.copy(fontSize = 48.sp), color = StatusSuccess)
                        Text(rating(avg), color = TextPrimary, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(top = 4.dp))
                        Text("Best round: $best ms", color = TextMuted,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                        Text("Tap to play again", color = TextMuted,
                            style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 16.dp))
                    }
                }
            }
        }
    }
}
