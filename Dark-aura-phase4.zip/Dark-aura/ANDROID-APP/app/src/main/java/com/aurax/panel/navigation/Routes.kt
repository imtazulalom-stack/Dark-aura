package com.aurax.panel.navigation

object Routes {
    const val SPLASH = "splash"
    const val ACTIVATION = "activation"
    const val GAME_SELECTION = "game_selection"
    const val HOME = "home"
}
