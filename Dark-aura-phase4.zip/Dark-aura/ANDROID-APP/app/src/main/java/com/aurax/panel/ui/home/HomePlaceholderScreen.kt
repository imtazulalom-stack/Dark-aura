package com.aurax.panel.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurax.panel.data.game.GamePreferences
import com.aurax.panel.ui.components.AuraLogo
import com.aurax.panel.ui.components.CyberBackground
import com.aurax.panel.ui.components.GlassCard
import com.aurax.panel.ui.components.NeonButton
import com.aurax.panel.ui.theme.NeonBlue
import com.aurax.panel.ui.theme.TextMuted

/** TEMPORARY. The real dashboard is built in Phase 5. */
@Composable
fun HomePlaceholderScreen(onChangeGame: () -> Unit) {
    val context = LocalContext.current
    val game = remember { GamePreferences(context).getSelected() }

    CyberBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AuraLogo(logoSize = 96.dp)
            Spacer(Modifier.height(24.dp))
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text("SELECTED GAME", style = MaterialTheme.typography.labelLarge, color = TextMuted)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = game?.title ?: "None",
                    style = MaterialTheme.typography.headlineMedium,
                    color = NeonBlue
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "The dashboard is built in Phase 5.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
                Spacer(Modifier.height(20.dp))
                NeonButton(text = "CHANGE GAME", onClick = onChangeGame)
            }
        }
    }
}
