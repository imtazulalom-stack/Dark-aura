package com.aurax.panel.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurax.panel.BuildConfig
import com.aurax.panel.ui.activation.ActivationScreen
import com.aurax.panel.ui.games.GameSelectionScreen
import com.aurax.panel.ui.home.HomePlaceholderScreen
import com.aurax.panel.ui.splash.SplashScreen

@Composable
fun AuraNavHost() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(600)) },
        exitTransition = { fadeOut(tween(600)) },
        popEnterTransition = { fadeIn(tween(600)) },
        popExitTransition = { fadeOut(tween(600)) }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    nav.navigate(Routes.ACTIVATION) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.ACTIVATION) {
            ActivationScreen(
                onActivated = { nav.goToGameSelectionAfterActivation() },
                // Debug builds only. In a release APK BuildConfig.DEBUG is false, so this is null.
                onDebugSkip = if (BuildConfig.DEBUG) {
                    { nav.goToGameSelectionAfterActivation() }
                } else null
            )
        }

        composable(Routes.GAME_SELECTION) {
            GameSelectionScreen(
                onContinue = {
                    // If we came from Home ("Change game"), just go back to it.
                    val cameFromHome = nav.popBackStack(Routes.HOME, inclusive = false)
                    if (!cameFromHome) {
                        nav.navigate(Routes.HOME) {
                            popUpTo(Routes.GAME_SELECTION) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomePlaceholderScreen(
                onChangeGame = { nav.navigate(Routes.GAME_SELECTION) }
            )
        }
    }
}

private fun NavHostController.goToGameSelectionAfterActivation() {
    navigate(Routes.GAME_SELECTION) {
        popUpTo(Routes.ACTIVATION) { inclusive = true }
    }
}
