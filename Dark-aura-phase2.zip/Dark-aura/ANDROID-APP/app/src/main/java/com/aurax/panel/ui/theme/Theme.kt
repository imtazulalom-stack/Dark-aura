package com.aurax.panel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AuraColorScheme = darkColorScheme(
    primary = NeonBlue,
    onPrimary = AuraBlack,
    secondary = NeonPurple,
    onSecondary = TextPrimary,
    tertiary = ElectricBlue,
    background = AuraBlack,
    onBackground = TextPrimary,
    surface = AuraSurface,
    onSurface = TextPrimary,
    surfaceVariant = AuraSurfaceHigh,
    onSurfaceVariant = TextMuted,
    error = StatusError
)

@Composable
fun AuraXTheme(content: @Composable () -> Unit) {
    // AURA X is always dark. Dynamic (wallpaper) colors are intentionally not used.
    MaterialTheme(
        colorScheme = AuraColorScheme,
        typography = AuraTypography,
        content = content
    )
}
