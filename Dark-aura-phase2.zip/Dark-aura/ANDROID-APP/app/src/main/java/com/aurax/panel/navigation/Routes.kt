package com.aurax.panel.navigation

object Routes {
    const val SPLASH = "splash"
    const val ACTIVATION = "activation"
}
