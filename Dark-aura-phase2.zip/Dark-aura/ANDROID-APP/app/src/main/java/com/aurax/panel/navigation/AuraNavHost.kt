package com.aurax.panel.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurax.panel.ui.activation.ActivationScreen
import com.aurax.panel.ui.splash.SplashScreen

@Composable
fun AuraNavHost() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.SPLASH,
        enterTransition = { fadeIn(tween(600)) },
        exitTransition = { fadeOut(tween(600)) },
        popEnterTransition = { fadeIn(tween(600)) },
        popExitTransition = { fadeOut(tween(600)) }
    ) {
        composable(Routes.SPLASH) {
            SplashScreen(
                onFinished = {
                    nav.navigate(Routes.ACTIVATION) {
                        // Remove splash from back stack so Back never returns to it
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.ACTIVATION) { ActivationScreen() }
    }
}
