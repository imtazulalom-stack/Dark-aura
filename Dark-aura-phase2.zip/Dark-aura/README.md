# AURA X (Dark-aura)

Free Fire practice panel: Android app (Kotlin + Jetpack Compose) + Admin website + Firebase.
Package: com.aurax.panel

Status: Phase 2 done (splash screen). See DOCUMENTATION/PROJECT-STRUCTURE.md for the plan
and DOCUMENTATION/PHASE-1.md to run the app.
Backend design (free Spark plan, Firestore rules): DOCUMENTATION/SETUP.md.
